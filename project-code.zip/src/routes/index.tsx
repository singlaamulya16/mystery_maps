import { createFileRoute } from "@tanstack/react-router";
import { Home } from "@/components/Home";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mystery Maps — Guess the Country Flag Game" },
      { name: "description", content: "A fast, addictive flag-guessing game with XP, streaks, daily challenges, and a global leaderboard. Play Classic, Speed, and Survival modes." },
      { property: "og:title", content: "Mystery Maps — Guess the Country Flag" },
      { property: "og:description", content: "Race the timer, build streaks, and learn fun facts about every country. Play now." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});
