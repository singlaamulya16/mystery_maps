export type Profile = {
  username: string;
  avatar: string;
  xp: number;
  totalCorrect: number;
  totalPlayed: number;
  bestStreak: number;
  achievements: string[];
  lastDailyDate?: string;
  dailyStreak: number;
};

export type LeaderboardEntry = {
  username: string;
  avatar: string;
  score: number;
  mode: string;
  date: number;
};

const PROFILE_KEY = "mm:profile";
const LB_KEY = "mm:leaderboard";

const AVATARS = ["🦊", "🐻", "🐯", "🦁", "🐼", "🐸", "🐵", "🦉", "🐲", "👽", "🤖", "🧙"];

const DEFAULT: Profile = {
  username: "Explorer",
  avatar: AVATARS[0],
  xp: 0,
  totalCorrect: 0,
  totalPlayed: 0,
  bestStreak: 0,
  achievements: [],
  dailyStreak: 0,
};

export const ACHIEVEMENTS: Record<string, { name: string; desc: string; icon: string }> = {
  first_blood: { name: "First Steps", desc: "Answer your first country", icon: "🎯" },
  streak_5: { name: "On Fire", desc: "5-answer streak", icon: "🔥" },
  streak_10: { name: "Unstoppable", desc: "10-answer streak", icon: "⚡" },
  streak_25: { name: "Legendary", desc: "25-answer streak", icon: "👑" },
  level_5: { name: "Geographer", desc: "Reach level 5", icon: "🗺️" },
  level_10: { name: "World Class", desc: "Reach level 10", icon: "🌍" },
  survivor: { name: "Survivor", desc: "Score 20+ in Survival", icon: "💀" },
  speedster: { name: "Speedster", desc: "Score 30+ in Speed", icon: "⚡️" },
  daily_3: { name: "Daily Devotee", desc: "3-day daily streak", icon: "📅" },
};

export function isClient() { return typeof window !== "undefined"; }

export function loadProfile(): Profile {
  if (!isClient()) return DEFAULT;
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) return DEFAULT;
    return { ...DEFAULT, ...JSON.parse(raw) };
  } catch { return DEFAULT; }
}

export function saveProfile(p: Profile) {
  if (!isClient()) return;
  localStorage.setItem(PROFILE_KEY, JSON.stringify(p));
}

export function levelFromXp(xp: number) {
  // level n requires n*100 cumulative... simpler: floor(sqrt(xp/50)) + 1
  const lvl = Math.floor(Math.sqrt(xp / 50)) + 1;
  const xpForLvl = (lvl - 1) ** 2 * 50;
  const xpForNext = lvl ** 2 * 50;
  const progress = (xp - xpForLvl) / (xpForNext - xpForLvl);
  return { level: lvl, progress, xpForNext, xpInto: xp - xpForLvl, xpNeeded: xpForNext - xpForLvl };
}

export function loadLeaderboard(): LeaderboardEntry[] {
  if (!isClient()) return [];
  try { return JSON.parse(localStorage.getItem(LB_KEY) || "[]"); } catch { return []; }
}

export function saveScore(entry: LeaderboardEntry) {
  if (!isClient()) return;
  const lb = loadLeaderboard();
  lb.push(entry);
  lb.sort((a, b) => b.score - a.score);
  localStorage.setItem(LB_KEY, JSON.stringify(lb.slice(0, 50)));
}

export const AVATAR_OPTIONS = AVATARS;

const USED_KEY = "mm:usedCountries";

export function loadUsedCountries(): string[] {
  if (!isClient()) return [];
  try { return JSON.parse(localStorage.getItem(USED_KEY) || "[]"); } catch { return []; }
}

export function saveUsedCountries(codes: string[]) {
  if (!isClient()) return;
  localStorage.setItem(USED_KEY, JSON.stringify(codes));
}

export function resetUsedCountries() {
  if (!isClient()) return;
  localStorage.removeItem(USED_KEY);
}

export function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}
