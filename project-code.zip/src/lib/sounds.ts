// Lightweight Web Audio synth - no asset files.
let ctx: AudioContext | null = null;
let muted = false;

function ac() {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    try {
      ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch {
      return null;
    }
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

function tone(freq: number, dur = 0.12, type: OscillatorType = "sine", gain = 0.15, when = 0) {
  const a = ac();
  if (!a || muted) return;
  const t = a.currentTime + when;
  const osc = a.createOscillator();
  const g = a.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(gain, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(g).connect(a.destination);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}

export const sfx = {
  setMuted(v: boolean) { muted = v; },
  isMuted() { return muted; },
  click() { tone(680, 0.06, "square", 0.08); },
  correct() {
    tone(660, 0.1, "triangle", 0.16, 0);
    tone(880, 0.12, "triangle", 0.16, 0.08);
    tone(1320, 0.18, "triangle", 0.14, 0.16);
  },
  wrong() {
    tone(220, 0.18, "sawtooth", 0.18, 0);
    tone(160, 0.22, "sawtooth", 0.16, 0.1);
  },
  tick() { tone(900, 0.04, "square", 0.06); },
  hint() { tone(520, 0.1, "sine", 0.14); tone(780, 0.14, "sine", 0.12, 0.08); },
  levelUp() {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.18, "triangle", 0.18, i * 0.08));
  },
  gameOver() {
    [440, 349, 277, 220].forEach((f, i) => tone(f, 0.22, "sawtooth", 0.16, i * 0.12));
  },
  combo() { tone(1200, 0.08, "square", 0.1); tone(1600, 0.1, "square", 0.1, 0.05); },
};
