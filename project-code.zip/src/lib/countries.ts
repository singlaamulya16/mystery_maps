export type Country = {
  name: string;
  code: string;
  flag: string;
  continent: "Africa" | "Asia" | "Europe" | "North America" | "South America" | "Oceania";
  capital: string;
  fact: string;
  landmark?: string;
  aliases?: string[];
};

const f = (code: string) => `https://flagcdn.com/w640/${code.toLowerCase()}.png`;

export const COUNTRIES: Country[] = [
  { name: "Afghanistan", code: "AF", flag: f("AF"), continent: "Asia", capital: "Kabul", fact: "Capital: Kabul."  },
  { name: "Albania", code: "AL", flag: f("AL"), continent: "Europe", capital: "Tirana", fact: "Capital: Tirana."  },
  { name: "Algeria", code: "DZ", flag: f("DZ"), continent: "Africa", capital: "Algiers", fact: "Capital: Algiers."  },
  { name: "Andorra", code: "AD", flag: f("AD"), continent: "Europe", capital: "Andorra la Vella", fact: "Capital: Andorra la Vella."  },
  { name: "Angola", code: "AO", flag: f("AO"), continent: "Africa", capital: "Luanda", fact: "Capital: Luanda."  },
  { name: "Antigua and Barbuda", code: "AG", flag: f("AG"), continent: "North America", capital: "Saint John's", fact: "Capital: Saint John's."  },
  { name: "Argentina", code: "AR", flag: f("AR"), continent: "South America", capital: "Buenos Aires", fact: "Capital: Buenos Aires."  },
  { name: "Armenia", code: "AM", flag: f("AM"), continent: "Asia", capital: "Yerevan", fact: "Capital: Yerevan."  },
  { name: "Australia", code: "AU", flag: f("AU"), continent: "Oceania", capital: "Canberra", fact: "Capital: Canberra."  },
  { name: "Austria", code: "AT", flag: f("AT"), continent: "Europe", capital: "Vienna", fact: "Capital: Vienna."  },
  { name: "Azerbaijan", code: "AZ", flag: f("AZ"), continent: "Asia", capital: "Baku", fact: "Capital: Baku."  },
  { name: "Bahamas", code: "BS", flag: f("BS"), continent: "North America", capital: "Nassau", fact: "Capital: Nassau."  },
  { name: "Bahrain", code: "BH", flag: f("BH"), continent: "Asia", capital: "Manama", fact: "Capital: Manama."  },
  { name: "Bangladesh", code: "BD", flag: f("BD"), continent: "Asia", capital: "Dhaka", fact: "Capital: Dhaka."  },
  { name: "Barbados", code: "BB", flag: f("BB"), continent: "North America", capital: "Bridgetown", fact: "Capital: Bridgetown."  },
  { name: "Belarus", code: "BY", flag: f("BY"), continent: "Europe", capital: "Minsk", fact: "Capital: Minsk."  },
  { name: "Belgium", code: "BE", flag: f("BE"), continent: "Europe", capital: "Brussels", fact: "Capital: Brussels."  },
  { name: "Belize", code: "BZ", flag: f("BZ"), continent: "North America", capital: "Belmopan", fact: "Capital: Belmopan."  },
  { name: "Benin", code: "BJ", flag: f("BJ"), continent: "Africa", capital: "Porto-Novo", fact: "Capital: Porto-Novo."  },
  { name: "Bhutan", code: "BT", flag: f("BT"), continent: "Asia", capital: "Thimphu", fact: "Capital: Thimphu."  },
  { name: "Bolivia", code: "BO", flag: f("BO"), continent: "South America", capital: "Sucre", fact: "Capital: Sucre."  },
  { name: "Bosnia and Herzegovina", code: "BA", flag: f("BA"), continent: "Europe", capital: "Sarajevo", fact: "Capital: Sarajevo."  },
  { name: "Botswana", code: "BW", flag: f("BW"), continent: "Africa", capital: "Gaborone", fact: "Capital: Gaborone."  },
  { name: "Brazil", code: "BR", flag: f("BR"), continent: "South America", capital: "Brasília", fact: "Capital: Brasília."  },
  { name: "Brunei", code: "BN", flag: f("BN"), continent: "Asia", capital: "Bandar Seri Begawan", fact: "Capital: Bandar Seri Begawan."  },
  { name: "Bulgaria", code: "BG", flag: f("BG"), continent: "Europe", capital: "Sofia", fact: "Capital: Sofia."  },
  { name: "Burkina Faso", code: "BF", flag: f("BF"), continent: "Africa", capital: "Ouagadougou", fact: "Capital: Ouagadougou."  },
  { name: "Burundi", code: "BI", flag: f("BI"), continent: "Africa", capital: "Gitega", fact: "Capital: Gitega."  },
  { name: "Cambodia", code: "KH", flag: f("KH"), continent: "Asia", capital: "Phnom Penh", fact: "Capital: Phnom Penh."  },
  { name: "Cameroon", code: "CM", flag: f("CM"), continent: "Africa", capital: "Yaoundé", fact: "Capital: Yaoundé."  },
  { name: "Canada", code: "CA", flag: f("CA"), continent: "North America", capital: "Ottawa", fact: "Capital: Ottawa."  },
  { name: "Cape Verde", code: "CV", flag: f("CV"), continent: "Africa", capital: "Praia", fact: "Capital: Praia."  },
  { name: "Central African Republic", code: "CF", flag: f("CF"), continent: "Africa", capital: "Bangui", fact: "Capital: Bangui."  },
  { name: "Chad", code: "TD", flag: f("TD"), continent: "Africa", capital: "N'Djamena", fact: "Capital: N'Djamena."  },
  { name: "Chile", code: "CL", flag: f("CL"), continent: "South America", capital: "Santiago", fact: "Capital: Santiago."  },
  { name: "China", code: "CN", flag: f("CN"), continent: "Asia", capital: "Beijing", fact: "Capital: Beijing."  },
  { name: "Colombia", code: "CO", flag: f("CO"), continent: "South America", capital: "Bogotá", fact: "Capital: Bogotá."  },
  { name: "Comoros", code: "KM", flag: f("KM"), continent: "Africa", capital: "Moroni", fact: "Capital: Moroni."  },
  { name: "Congo", code: "CG", flag: f("CG"), continent: "Africa", capital: "Brazzaville", fact: "Capital: Brazzaville."  },
  { name: "DR Congo", code: "CD", flag: f("CD"), continent: "Africa", capital: "Kinshasa", fact: "Capital: Kinshasa." , aliases: ["democratic republic of the congo", "drc"] },
  { name: "Costa Rica", code: "CR", flag: f("CR"), continent: "North America", capital: "San José", fact: "Capital: San José."  },
  { name: "Croatia", code: "HR", flag: f("HR"), continent: "Europe", capital: "Zagreb", fact: "Capital: Zagreb."  },
  { name: "Cuba", code: "CU", flag: f("CU"), continent: "North America", capital: "Havana", fact: "Capital: Havana."  },
  { name: "Cyprus", code: "CY", flag: f("CY"), continent: "Europe", capital: "Nicosia", fact: "Capital: Nicosia."  },
  { name: "Czech Republic", code: "CZ", flag: f("CZ"), continent: "Europe", capital: "Prague", fact: "Capital: Prague." , aliases: ["czechia"] },
  { name: "Denmark", code: "DK", flag: f("DK"), continent: "Europe", capital: "Copenhagen", fact: "Capital: Copenhagen."  },
  { name: "Djibouti", code: "DJ", flag: f("DJ"), continent: "Africa", capital: "Djibouti", fact: "Capital: Djibouti."  },
  { name: "Dominica", code: "DM", flag: f("DM"), continent: "North America", capital: "Roseau", fact: "Capital: Roseau."  },
  { name: "Dominican Republic", code: "DO", flag: f("DO"), continent: "North America", capital: "Santo Domingo", fact: "Capital: Santo Domingo."  },
  { name: "Ecuador", code: "EC", flag: f("EC"), continent: "South America", capital: "Quito", fact: "Capital: Quito."  },
  { name: "Egypt", code: "EG", flag: f("EG"), continent: "Africa", capital: "Cairo", fact: "Capital: Cairo."  },
  { name: "El Salvador", code: "SV", flag: f("SV"), continent: "North America", capital: "San Salvador", fact: "Capital: San Salvador."  },
  { name: "Equatorial Guinea", code: "GQ", flag: f("GQ"), continent: "Africa", capital: "Malabo", fact: "Capital: Malabo."  },
  { name: "Eritrea", code: "ER", flag: f("ER"), continent: "Africa", capital: "Asmara", fact: "Capital: Asmara."  },
  { name: "Estonia", code: "EE", flag: f("EE"), continent: "Europe", capital: "Tallinn", fact: "Capital: Tallinn."  },
  { name: "Eswatini", code: "SZ", flag: f("SZ"), continent: "Africa", capital: "Mbabane", fact: "Capital: Mbabane." , aliases: ["swaziland"] },
  { name: "Ethiopia", code: "ET", flag: f("ET"), continent: "Africa", capital: "Addis Ababa", fact: "Capital: Addis Ababa."  },
  { name: "Fiji", code: "FJ", flag: f("FJ"), continent: "Oceania", capital: "Suva", fact: "Capital: Suva."  },
  { name: "Finland", code: "FI", flag: f("FI"), continent: "Europe", capital: "Helsinki", fact: "Capital: Helsinki."  },
  { name: "France", code: "FR", flag: f("FR"), continent: "Europe", capital: "Paris", fact: "Capital: Paris."  },
  { name: "Gabon", code: "GA", flag: f("GA"), continent: "Africa", capital: "Libreville", fact: "Capital: Libreville."  },
  { name: "Gambia", code: "GM", flag: f("GM"), continent: "Africa", capital: "Banjul", fact: "Capital: Banjul."  },
  { name: "Georgia", code: "GE", flag: f("GE"), continent: "Asia", capital: "Tbilisi", fact: "Capital: Tbilisi."  },
  { name: "Germany", code: "DE", flag: f("DE"), continent: "Europe", capital: "Berlin", fact: "Capital: Berlin."  },
  { name: "Ghana", code: "GH", flag: f("GH"), continent: "Africa", capital: "Accra", fact: "Capital: Accra."  },
  { name: "Greece", code: "GR", flag: f("GR"), continent: "Europe", capital: "Athens", fact: "Capital: Athens."  },
  { name: "Grenada", code: "GD", flag: f("GD"), continent: "North America", capital: "Saint George's", fact: "Capital: Saint George's."  },
  { name: "Guatemala", code: "GT", flag: f("GT"), continent: "North America", capital: "Guatemala City", fact: "Capital: Guatemala City."  },
  { name: "Guinea", code: "GN", flag: f("GN"), continent: "Africa", capital: "Conakry", fact: "Capital: Conakry."  },
  { name: "Guinea-Bissau", code: "GW", flag: f("GW"), continent: "Africa", capital: "Bissau", fact: "Capital: Bissau."  },
  { name: "Guyana", code: "GY", flag: f("GY"), continent: "South America", capital: "Georgetown", fact: "Capital: Georgetown."  },
  { name: "Haiti", code: "HT", flag: f("HT"), continent: "North America", capital: "Port-au-Prince", fact: "Capital: Port-au-Prince."  },
  { name: "Honduras", code: "HN", flag: f("HN"), continent: "North America", capital: "Tegucigalpa", fact: "Capital: Tegucigalpa."  },
  { name: "Hungary", code: "HU", flag: f("HU"), continent: "Europe", capital: "Budapest", fact: "Capital: Budapest."  },
  { name: "Iceland", code: "IS", flag: f("IS"), continent: "Europe", capital: "Reykjavík", fact: "Capital: Reykjavík."  },
  { name: "India", code: "IN", flag: f("IN"), continent: "Asia", capital: "New Delhi", fact: "Capital: New Delhi."  },
  { name: "Indonesia", code: "ID", flag: f("ID"), continent: "Asia", capital: "Jakarta", fact: "Capital: Jakarta."  },
  { name: "Iran", code: "IR", flag: f("IR"), continent: "Asia", capital: "Tehran", fact: "Capital: Tehran."  },
  { name: "Iraq", code: "IQ", flag: f("IQ"), continent: "Asia", capital: "Baghdad", fact: "Capital: Baghdad."  },
  { name: "Ireland", code: "IE", flag: f("IE"), continent: "Europe", capital: "Dublin", fact: "Capital: Dublin."  },
  { name: "Israel", code: "IL", flag: f("IL"), continent: "Asia", capital: "Jerusalem", fact: "Capital: Jerusalem."  },
  { name: "Italy", code: "IT", flag: f("IT"), continent: "Europe", capital: "Rome", fact: "Capital: Rome."  },
  { name: "Ivory Coast", code: "CI", flag: f("CI"), continent: "Africa", capital: "Yamoussoukro", fact: "Capital: Yamoussoukro." , aliases: ["cote d ivoire", "côte d'ivoire"] },
  { name: "Jamaica", code: "JM", flag: f("JM"), continent: "North America", capital: "Kingston", fact: "Capital: Kingston."  },
  { name: "Japan", code: "JP", flag: f("JP"), continent: "Asia", capital: "Tokyo", fact: "Capital: Tokyo."  },
  { name: "Jordan", code: "JO", flag: f("JO"), continent: "Asia", capital: "Amman", fact: "Capital: Amman."  },
  { name: "Kazakhstan", code: "KZ", flag: f("KZ"), continent: "Asia", capital: "Astana", fact: "Capital: Astana."  },
  { name: "Kenya", code: "KE", flag: f("KE"), continent: "Africa", capital: "Nairobi", fact: "Capital: Nairobi."  },
  { name: "Kiribati", code: "KI", flag: f("KI"), continent: "Oceania", capital: "Tarawa", fact: "Capital: Tarawa."  },
  { name: "Kosovo", code: "XK", flag: f("XK"), continent: "Europe", capital: "Pristina", fact: "Capital: Pristina."  },
  { name: "Kuwait", code: "KW", flag: f("KW"), continent: "Asia", capital: "Kuwait City", fact: "Capital: Kuwait City."  },
  { name: "Kyrgyzstan", code: "KG", flag: f("KG"), continent: "Asia", capital: "Bishkek", fact: "Capital: Bishkek."  },
  { name: "Laos", code: "LA", flag: f("LA"), continent: "Asia", capital: "Vientiane", fact: "Capital: Vientiane."  },
  { name: "Latvia", code: "LV", flag: f("LV"), continent: "Europe", capital: "Riga", fact: "Capital: Riga."  },
  { name: "Lebanon", code: "LB", flag: f("LB"), continent: "Asia", capital: "Beirut", fact: "Capital: Beirut."  },
  { name: "Lesotho", code: "LS", flag: f("LS"), continent: "Africa", capital: "Maseru", fact: "Capital: Maseru."  },
  { name: "Liberia", code: "LR", flag: f("LR"), continent: "Africa", capital: "Monrovia", fact: "Capital: Monrovia."  },
  { name: "Libya", code: "LY", flag: f("LY"), continent: "Africa", capital: "Tripoli", fact: "Capital: Tripoli."  },
  { name: "Liechtenstein", code: "LI", flag: f("LI"), continent: "Europe", capital: "Vaduz", fact: "Capital: Vaduz."  },
  { name: "Lithuania", code: "LT", flag: f("LT"), continent: "Europe", capital: "Vilnius", fact: "Capital: Vilnius."  },
  { name: "Luxembourg", code: "LU", flag: f("LU"), continent: "Europe", capital: "Luxembourg", fact: "Capital: Luxembourg."  },
  { name: "Madagascar", code: "MG", flag: f("MG"), continent: "Africa", capital: "Antananarivo", fact: "Capital: Antananarivo."  },
  { name: "Malawi", code: "MW", flag: f("MW"), continent: "Africa", capital: "Lilongwe", fact: "Capital: Lilongwe."  },
  { name: "Malaysia", code: "MY", flag: f("MY"), continent: "Asia", capital: "Kuala Lumpur", fact: "Capital: Kuala Lumpur."  },
  { name: "Maldives", code: "MV", flag: f("MV"), continent: "Asia", capital: "Malé", fact: "Capital: Malé."  },
  { name: "Mali", code: "ML", flag: f("ML"), continent: "Africa", capital: "Bamako", fact: "Capital: Bamako."  },
  { name: "Malta", code: "MT", flag: f("MT"), continent: "Europe", capital: "Valletta", fact: "Capital: Valletta."  },
  { name: "Marshall Islands", code: "MH", flag: f("MH"), continent: "Oceania", capital: "Majuro", fact: "Capital: Majuro."  },
  { name: "Mauritania", code: "MR", flag: f("MR"), continent: "Africa", capital: "Nouakchott", fact: "Capital: Nouakchott."  },
  { name: "Mauritius", code: "MU", flag: f("MU"), continent: "Africa", capital: "Port Louis", fact: "Capital: Port Louis."  },
  { name: "Mexico", code: "MX", flag: f("MX"), continent: "North America", capital: "Mexico City", fact: "Capital: Mexico City."  },
  { name: "Micronesia", code: "FM", flag: f("FM"), continent: "Oceania", capital: "Palikir", fact: "Capital: Palikir."  },
  { name: "Moldova", code: "MD", flag: f("MD"), continent: "Europe", capital: "Chișinău", fact: "Capital: Chișinău."  },
  { name: "Monaco", code: "MC", flag: f("MC"), continent: "Europe", capital: "Monaco", fact: "Capital: Monaco."  },
  { name: "Mongolia", code: "MN", flag: f("MN"), continent: "Asia", capital: "Ulaanbaatar", fact: "Capital: Ulaanbaatar."  },
  { name: "Montenegro", code: "ME", flag: f("ME"), continent: "Europe", capital: "Podgorica", fact: "Capital: Podgorica."  },
  { name: "Morocco", code: "MA", flag: f("MA"), continent: "Africa", capital: "Rabat", fact: "Capital: Rabat."  },
  { name: "Mozambique", code: "MZ", flag: f("MZ"), continent: "Africa", capital: "Maputo", fact: "Capital: Maputo."  },
  { name: "Myanmar", code: "MM", flag: f("MM"), continent: "Asia", capital: "Naypyidaw", fact: "Capital: Naypyidaw." , aliases: ["burma"] },
  { name: "Namibia", code: "NA", flag: f("NA"), continent: "Africa", capital: "Windhoek", fact: "Capital: Windhoek."  },
  { name: "Nauru", code: "NR", flag: f("NR"), continent: "Oceania", capital: "Yaren", fact: "Capital: Yaren."  },
  { name: "Nepal", code: "NP", flag: f("NP"), continent: "Asia", capital: "Kathmandu", fact: "Capital: Kathmandu."  },
  { name: "Netherlands", code: "NL", flag: f("NL"), continent: "Europe", capital: "Amsterdam", fact: "Capital: Amsterdam." , aliases: ["holland"] },
  { name: "New Zealand", code: "NZ", flag: f("NZ"), continent: "Oceania", capital: "Wellington", fact: "Capital: Wellington."  },
  { name: "Nicaragua", code: "NI", flag: f("NI"), continent: "North America", capital: "Managua", fact: "Capital: Managua."  },
  { name: "Niger", code: "NE", flag: f("NE"), continent: "Africa", capital: "Niamey", fact: "Capital: Niamey."  },
  { name: "Nigeria", code: "NG", flag: f("NG"), continent: "Africa", capital: "Abuja", fact: "Capital: Abuja."  },
  { name: "North Korea", code: "KP", flag: f("KP"), continent: "Asia", capital: "Pyongyang", fact: "Capital: Pyongyang."  },
  { name: "North Macedonia", code: "MK", flag: f("MK"), continent: "Europe", capital: "Skopje", fact: "Capital: Skopje." , aliases: ["macedonia"] },
  { name: "Norway", code: "NO", flag: f("NO"), continent: "Europe", capital: "Oslo", fact: "Capital: Oslo."  },
  { name: "Oman", code: "OM", flag: f("OM"), continent: "Asia", capital: "Muscat", fact: "Capital: Muscat."  },
  { name: "Pakistan", code: "PK", flag: f("PK"), continent: "Asia", capital: "Islamabad", fact: "Capital: Islamabad."  },
  { name: "Palau", code: "PW", flag: f("PW"), continent: "Oceania", capital: "Ngerulmud", fact: "Capital: Ngerulmud."  },
  { name: "Palestine", code: "PS", flag: f("PS"), continent: "Asia", capital: "Ramallah", fact: "Capital: Ramallah."  },
  { name: "Panama", code: "PA", flag: f("PA"), continent: "North America", capital: "Panama City", fact: "Capital: Panama City."  },
  { name: "Papua New Guinea", code: "PG", flag: f("PG"), continent: "Oceania", capital: "Port Moresby", fact: "Capital: Port Moresby."  },
  { name: "Paraguay", code: "PY", flag: f("PY"), continent: "South America", capital: "Asunción", fact: "Capital: Asunción."  },
  { name: "Peru", code: "PE", flag: f("PE"), continent: "South America", capital: "Lima", fact: "Capital: Lima."  },
  { name: "Philippines", code: "PH", flag: f("PH"), continent: "Asia", capital: "Manila", fact: "Capital: Manila."  },
  { name: "Poland", code: "PL", flag: f("PL"), continent: "Europe", capital: "Warsaw", fact: "Capital: Warsaw."  },
  { name: "Portugal", code: "PT", flag: f("PT"), continent: "Europe", capital: "Lisbon", fact: "Capital: Lisbon."  },
  { name: "Qatar", code: "QA", flag: f("QA"), continent: "Asia", capital: "Doha", fact: "Capital: Doha."  },
  { name: "Romania", code: "RO", flag: f("RO"), continent: "Europe", capital: "Bucharest", fact: "Capital: Bucharest."  },
  { name: "Russia", code: "RU", flag: f("RU"), continent: "Europe", capital: "Moscow", fact: "Capital: Moscow."  },
  { name: "Rwanda", code: "RW", flag: f("RW"), continent: "Africa", capital: "Kigali", fact: "Capital: Kigali."  },
  { name: "Saint Kitts and Nevis", code: "KN", flag: f("KN"), continent: "North America", capital: "Basseterre", fact: "Capital: Basseterre."  },
  { name: "Saint Lucia", code: "LC", flag: f("LC"), continent: "North America", capital: "Castries", fact: "Capital: Castries."  },
  { name: "Saint Vincent and the Grenadines", code: "VC", flag: f("VC"), continent: "North America", capital: "Kingstown", fact: "Capital: Kingstown."  },
  { name: "Samoa", code: "WS", flag: f("WS"), continent: "Oceania", capital: "Apia", fact: "Capital: Apia."  },
  { name: "San Marino", code: "SM", flag: f("SM"), continent: "Europe", capital: "San Marino", fact: "Capital: San Marino."  },
  { name: "Sao Tome and Principe", code: "ST", flag: f("ST"), continent: "Africa", capital: "São Tomé", fact: "Capital: São Tomé."  },
  { name: "Saudi Arabia", code: "SA", flag: f("SA"), continent: "Asia", capital: "Riyadh", fact: "Capital: Riyadh."  },
  { name: "Senegal", code: "SN", flag: f("SN"), continent: "Africa", capital: "Dakar", fact: "Capital: Dakar."  },
  { name: "Serbia", code: "RS", flag: f("RS"), continent: "Europe", capital: "Belgrade", fact: "Capital: Belgrade."  },
  { name: "Seychelles", code: "SC", flag: f("SC"), continent: "Africa", capital: "Victoria", fact: "Capital: Victoria."  },
  { name: "Sierra Leone", code: "SL", flag: f("SL"), continent: "Africa", capital: "Freetown", fact: "Capital: Freetown."  },
  { name: "Singapore", code: "SG", flag: f("SG"), continent: "Asia", capital: "Singapore", fact: "Capital: Singapore."  },
  { name: "Slovakia", code: "SK", flag: f("SK"), continent: "Europe", capital: "Bratislava", fact: "Capital: Bratislava."  },
  { name: "Slovenia", code: "SI", flag: f("SI"), continent: "Europe", capital: "Ljubljana", fact: "Capital: Ljubljana."  },
  { name: "Solomon Islands", code: "SB", flag: f("SB"), continent: "Oceania", capital: "Honiara", fact: "Capital: Honiara."  },
  { name: "Somalia", code: "SO", flag: f("SO"), continent: "Africa", capital: "Mogadishu", fact: "Capital: Mogadishu."  },
  { name: "South Africa", code: "ZA", flag: f("ZA"), continent: "Africa", capital: "Pretoria", fact: "Capital: Pretoria."  },
  { name: "South Korea", code: "KR", flag: f("KR"), continent: "Asia", capital: "Seoul", fact: "Capital: Seoul." , aliases: ["korea"] },
  { name: "South Sudan", code: "SS", flag: f("SS"), continent: "Africa", capital: "Juba", fact: "Capital: Juba."  },
  { name: "Spain", code: "ES", flag: f("ES"), continent: "Europe", capital: "Madrid", fact: "Capital: Madrid."  },
  { name: "Sri Lanka", code: "LK", flag: f("LK"), continent: "Asia", capital: "Colombo", fact: "Capital: Colombo."  },
  { name: "Sudan", code: "SD", flag: f("SD"), continent: "Africa", capital: "Khartoum", fact: "Capital: Khartoum."  },
  { name: "Suriname", code: "SR", flag: f("SR"), continent: "South America", capital: "Paramaribo", fact: "Capital: Paramaribo."  },
  { name: "Sweden", code: "SE", flag: f("SE"), continent: "Europe", capital: "Stockholm", fact: "Capital: Stockholm."  },
  { name: "Switzerland", code: "CH", flag: f("CH"), continent: "Europe", capital: "Bern", fact: "Capital: Bern."  },
  { name: "Syria", code: "SY", flag: f("SY"), continent: "Asia", capital: "Damascus", fact: "Capital: Damascus."  },
  { name: "Taiwan", code: "TW", flag: f("TW"), continent: "Asia", capital: "Taipei", fact: "Capital: Taipei."  },
  { name: "Tajikistan", code: "TJ", flag: f("TJ"), continent: "Asia", capital: "Dushanbe", fact: "Capital: Dushanbe."  },
  { name: "Tanzania", code: "TZ", flag: f("TZ"), continent: "Africa", capital: "Dodoma", fact: "Capital: Dodoma."  },
  { name: "Thailand", code: "TH", flag: f("TH"), continent: "Asia", capital: "Bangkok", fact: "Capital: Bangkok."  },
  { name: "Timor-Leste", code: "TL", flag: f("TL"), continent: "Asia", capital: "Dili", fact: "Capital: Dili." , aliases: ["east timor"] },
  { name: "Togo", code: "TG", flag: f("TG"), continent: "Africa", capital: "Lomé", fact: "Capital: Lomé."  },
  { name: "Tonga", code: "TO", flag: f("TO"), continent: "Oceania", capital: "Nukuʻalofa", fact: "Capital: Nukuʻalofa."  },
  { name: "Trinidad and Tobago", code: "TT", flag: f("TT"), continent: "North America", capital: "Port of Spain", fact: "Capital: Port of Spain."  },
  { name: "Tunisia", code: "TN", flag: f("TN"), continent: "Africa", capital: "Tunis", fact: "Capital: Tunis."  },
  { name: "Turkey", code: "TR", flag: f("TR"), continent: "Asia", capital: "Ankara", fact: "Capital: Ankara."  },
  { name: "Turkmenistan", code: "TM", flag: f("TM"), continent: "Asia", capital: "Ashgabat", fact: "Capital: Ashgabat."  },
  { name: "Tuvalu", code: "TV", flag: f("TV"), continent: "Oceania", capital: "Funafuti", fact: "Capital: Funafuti."  },
  { name: "Uganda", code: "UG", flag: f("UG"), continent: "Africa", capital: "Kampala", fact: "Capital: Kampala."  },
  { name: "Ukraine", code: "UA", flag: f("UA"), continent: "Europe", capital: "Kyiv", fact: "Capital: Kyiv."  },
  { name: "United Arab Emirates", code: "AE", flag: f("AE"), continent: "Asia", capital: "Abu Dhabi", fact: "Capital: Abu Dhabi." , aliases: ["uae", "emirates"] },
  { name: "United Kingdom", code: "GB", flag: f("GB"), continent: "Europe", capital: "London", fact: "Capital: London." , aliases: ["uk", "britain", "great britain", "england"] },
  { name: "United States", code: "US", flag: f("US"), continent: "North America", capital: "Washington, D.C.", fact: "Capital: Washington, D.C.." , aliases: ["usa", "us", "america", "united states of america"] },
  { name: "Uruguay", code: "UY", flag: f("UY"), continent: "South America", capital: "Montevideo", fact: "Capital: Montevideo."  },
  { name: "Uzbekistan", code: "UZ", flag: f("UZ"), continent: "Asia", capital: "Tashkent", fact: "Capital: Tashkent."  },
  { name: "Vanuatu", code: "VU", flag: f("VU"), continent: "Oceania", capital: "Port Vila", fact: "Capital: Port Vila."  },
  { name: "Vatican City", code: "VA", flag: f("VA"), continent: "Europe", capital: "Vatican City", fact: "Capital: Vatican City." , aliases: ["holy see"] },
  { name: "Venezuela", code: "VE", flag: f("VE"), continent: "South America", capital: "Caracas", fact: "Capital: Caracas."  },
  { name: "Vietnam", code: "VN", flag: f("VN"), continent: "Asia", capital: "Hanoi", fact: "Capital: Hanoi."  },
  { name: "Yemen", code: "YE", flag: f("YE"), continent: "Asia", capital: "Sanaa", fact: "Capital: Sanaa."  },
  { name: "Zambia", code: "ZM", flag: f("ZM"), continent: "Africa", capital: "Lusaka", fact: "Capital: Lusaka."  },
  { name: "Zimbabwe", code: "ZW", flag: f("ZW"), continent: "Africa", capital: "Harare", fact: "Capital: Harare."  },
];

export function normalize(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function matches(country: Country, guess: string) {
  const g = normalize(guess);
  if (!g) return false;
  if (g === normalize(country.name)) return true;
  return (country.aliases ?? []).some((a) => normalize(a) === g);
}

export type Difficulty = "beginner" | "intermediate" | "advanced" | "expert";

export type CategoryKind = "continent" | "oceans" | "general";
export type Continent = Country["continent"];
export type CategorySelection = { kind: "continent"; continent: Continent } | { kind: "oceans" } | { kind: "general" };

// Popular / well-known countries (easy tier)
export const POPULAR_CODES = new Set([
  "US","GB","FR","DE","IT","ES","PT","NL","BE","SE","NO","FI","DK","IE","PL","GR","CH","AT","CZ","RU","UA","TR",
  "CN","JP","KR","KP","IN","PK","BD","TH","VN","ID","PH","MY","SG","SA","AE","IL","IR","IQ","AF",
  "EG","ZA","NG","KE","ET","MA","DZ","TN","GH",
  "CA","MX","BR","AR","CL","CO","PE","VE","CU","JM",
  "AU","NZ",
]);

// Moderately known countries (medium tier on top of popular)
export const MEDIUM_CODES = new Set([
  "HU","RO","BG","HR","RS","SK","SI","EE","LV","LT","BY","IS","LU","MT","CY","AL","BA","MK","ME","XK","MD","GE","AM","AZ",
  "QA","KW","BH","OM","JO","LB","SY","YE","NP","LK","MM","KH","LA","MN","KZ","UZ","TM","KG","TJ","TW","HK","BT","MV",
  "LY","SD","SS","SN","CI","ML","UG","TZ","RW","ZW","ZM","MZ","MG","CM","AO","NA","BW","CD","CG","GA","MR",
  "GT","HN","SV","NI","CR","PA","DO","HT","PR","TT","BS","BB","BZ","UY","PY","EC","BO","SR","GY",
  "FJ","PG","WS","TO","VU","SB",
]);

export function getCountryPool(difficulty: Difficulty): Country[] {
  if (difficulty === "beginner") {
    return COUNTRIES.filter((c) => POPULAR_CODES.has(c.code));
  }
  if (difficulty === "intermediate") {
    return COUNTRIES.filter((c) => POPULAR_CODES.has(c.code) || MEDIUM_CODES.has(c.code));
  }
  if (difficulty === "advanced") {
    return COUNTRIES.filter((c) => !POPULAR_CODES.has(c.code));
  }
  // expert: only the obscure
  const hardPool = COUNTRIES.filter((c) => !POPULAR_CODES.has(c.code) && !MEDIUM_CODES.has(c.code));
  return hardPool.length >= 8 ? hardPool : COUNTRIES;
}

export function getCountryPoolFiltered(difficulty: Difficulty, category: CategorySelection): Country[] {
  const base = getCountryPool(difficulty);
  let filtered = base;
  if (category.kind === "continent") {
    filtered = base.filter((c) => c.continent === category.continent);
  } else if (category.kind === "oceans") {
    filtered = base.filter((c) => c.continent === "Oceania");
  }
  // Fallback: if filter is too small, drop the difficulty filter but keep category
  if (filtered.length < 8) {
    if (category.kind === "continent") return COUNTRIES.filter((c) => c.continent === category.continent);
    if (category.kind === "oceans") return COUNTRIES.filter((c) => c.continent === "Oceania");
    return COUNTRIES;
  }
  return filtered;
}

// ============= Lookalike Flag Groups =============
// Pairs/sets of countries whose flags look very similar — used in "Lookalike" mode.
const LOOKALIKE_CODE_GROUPS: string[][] = [
  ["AU", "NZ"],                     // Australia vs New Zealand
  ["ID", "MC", "PL"],               // Indonesia / Monaco / Poland (reversed)
  ["RO", "TD", "AD", "MD"],         // Romania / Chad / Andorra / Moldova
  ["NL", "LU", "RU"],               // Netherlands / Luxembourg / Russia
  ["IE", "CI"],                     // Ireland vs Ivory Coast
  ["IT", "MX", "HU"],               // Italy / Mexico / Hungary tri-bands
  ["NO", "IS"],                     // Norway vs Iceland (Nordic cross)
  ["SE", "FI"],                     // Sweden vs Finland (Nordic cross)
  ["EG", "SY", "IQ", "YE"],         // Arab tricolor
  ["CO", "EC", "VE"],               // Colombia / Ecuador / Venezuela
  ["SV", "NI", "HN", "AR"],         // Blue-white-blue Latin
  ["SN", "ML", "GN", "CM"],         // Pan-African vertical
  ["VN", "MA"],                     // Red w/ yellow star vs red w/ green star
  ["TR", "TN"],                     // Red w/ crescent
];

export function getLookalikeGroups(): Country[][] {
  const byCode = new Map(COUNTRIES.map((c) => [c.code, c]));
  return LOOKALIKE_CODE_GROUPS
    .map((codes) => codes.map((c) => byCode.get(c)).filter(Boolean) as Country[])
    .filter((g) => g.length >= 2);
}


