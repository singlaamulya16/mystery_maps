import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { COUNTRIES, getCountryPool, getCountryPoolFiltered, getLookalikeGroups, type Country, type Difficulty, type CategorySelection } from "@/lib/countries";

import { sfx } from "@/lib/sounds";
import { ACHIEVEMENTS, levelFromXp, loadProfile, loadUsedCountries, saveProfile, saveScore, saveUsedCountries, type Profile } from "@/lib/game-store";
import { ParticleBurst } from "./Particles";
import { Button } from "@/components/ui/button";
import { X, Trophy, Flame, Zap, SkipForward } from "lucide-react";

const TIME_PER_ROUND = 7;
const LIVES = 3;
const RAPID_TOTAL_TIME = 10;
const RAPID_ROUNDS = 7;


function pickFrom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}
function pickUnused(pool: Country[], used: Set<string>): Country {
  const remaining = pool.filter((c) => !used.has(c.code));
  return pickFrom(remaining.length ? remaining : pool);
}

function buildOptions(correct: Country, pool: Country[]): Country[] {
  const distractorPool = pool.filter((c) => c.name !== correct.name);
  const source = distractorPool.length >= 3 ? distractorPool : COUNTRIES.filter((c) => c.name !== correct.name);
  const wrongs: Country[] = [];
  while (wrongs.length < 3) {
    const c = source[Math.floor(Math.random() * source.length)];
    if (!wrongs.includes(c)) wrongs.push(c);
  }
  const all = [correct, ...wrongs];
  for (let i = all.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [all[i], all[j]] = [all[j], all[i]];
  }
  return all;
}

type FeedbackKind = "correct" | "wrong" | "timeout" | null;

export type GameMode = "classic" | "rapid" | "lookalike";
export type GameSettings = {
  rounds: number;
  difficulty: Difficulty;
  mode?: GameMode;
  category?: CategorySelection;
};

export function Game({ onExit, settings }: { onExit: () => void; settings: GameSettings }) {
  const isRapid = settings.mode === "rapid";
  const isLookalike = settings.mode === "lookalike";
  const TOTAL_ROUNDS = isRapid ? RAPID_ROUNDS : settings.rounds;
  const PER_ROUND_TIME = isRapid ? RAPID_TOTAL_TIME : TIME_PER_ROUND;
  const category: CategorySelection = settings.category ?? { kind: "general" };
  const categoryLabel = category.kind === "continent" ? category.continent : category.kind === "oceans" ? "Oceans" : "General";
  const modeLabel = isRapid ? "Rapid Fire" : isLookalike ? "Lookalike" : "Classic";
  const MODE_LABEL = `${modeLabel} · ${settings.difficulty[0].toUpperCase()}${settings.difficulty.slice(1)} · ${categoryLabel} · ${TOTAL_ROUNDS}Q`;
  const lookalikeGroupsRef = useRef<Country[][]>(getLookalikeGroups());

  const poolRef = useRef<Country[]>(getCountryPoolFiltered(settings.difficulty, category));
  const [profile, setProfile] = useState<Profile>(() => loadProfile());
  const usedRef = useRef<Set<string>>(new Set());

  const pickLookalike = useCallback((): { country: Country; options: Country[] } => {
    const groups = lookalikeGroupsRef.current;
    const group = pickFrom(groups);
    const correct = pickFrom(group);
    const opts = [...group].sort(() => Math.random() - 0.5);
    return { country: correct, options: opts };
  }, []);

  const [country, setCountry] = useState<Country>(() => {
    if (isLookalike) return pickLookalike().country;
    const pool = poolRef.current;
    let used = new Set(loadUsedCountries());
    if (pool.every((c) => used.has(c.code))) used = new Set();
    usedRef.current = used;
    const c = pickUnused(pool, used);
    usedRef.current.add(c.code);
    saveUsedCountries(Array.from(usedRef.current));
    return c;
  });
  const [options, setOptions] = useState<Country[]>(() =>
    isLookalike
      ? (() => {
          // Find the group containing initial country and shuffle it.
          const group = lookalikeGroupsRef.current.find((g) => g.some((c) => c.code === country.code)) ?? [country];
          return [...group].sort(() => Math.random() - 0.5);
        })()
      : buildOptions(country, poolRef.current),
  );

  const [picked, setPicked] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [lives, setLives] = useState(isRapid ? 99 : LIVES);
  const [round, setRound] = useState(1);
  const [time, setTime] = useState(PER_ROUND_TIME);
  const [feedback, setFeedback] = useState<FeedbackKind>(null);
  const [skips, setSkips] = useState(0);
  const [wrongs, setWrongs] = useState(0);
  const [factShown, setFactShown] = useState<{ country: Country } | null>(null);
  const [burst, setBurst] = useState(0);
  const [burstColor, setBurstColor] = useState<"success" | "destructive" | "accent">("success");
  const [over, setOver] = useState(false);
  const [recentXP, setRecentXP] = useState<{ amount: number; key: number } | null>(null);
  const [newAchievements, setNewAchievements] = useState<string[]>([]);

  const multiplier = useMemo(() => 1 + Math.floor(streak / 3) * 0.5, [streak]);
  const lvl = levelFromXp(profile.xp);

  const grantAchievements = useCallback((p: Profile, ctx: { streak: number; lvl: number; score: number }) => {
    const earned: string[] = [];
    const has = (k: string) => p.achievements.includes(k);
    const add = (k: string) => { if (!has(k)) { p.achievements.push(k); earned.push(k); } };
    if (p.totalCorrect >= 1) add("first_blood");
    if (ctx.streak >= 5) add("streak_5");
    if (ctx.streak >= 10) add("streak_10");
    if (ctx.streak >= 25) add("streak_25");
    if (ctx.lvl >= 5) add("level_5");
    if (ctx.lvl >= 10) add("level_10");
    if (p.dailyStreak >= 3) add("daily_3");
    return earned;
  }, []);

  const nextRound = useCallback(() => {
    if (isLookalike) {
      const { country: next, options: opts } = pickLookalike();
      setCountry(next);
      setOptions(opts);
      setPicked(null);
      if (!isRapid) setTime(PER_ROUND_TIME);
      setFeedback(null);
      return;
    }
    const pool = poolRef.current;
    if (pool.every((c) => usedRef.current.has(c.code))) usedRef.current = new Set();
    const next = pickUnused(pool, usedRef.current);
    usedRef.current.add(next.code);
    saveUsedCountries(Array.from(usedRef.current));
    setCountry(next);
    setOptions(buildOptions(next, pool));
    setPicked(null);
    if (!isRapid) setTime(PER_ROUND_TIME);
    setFeedback(null);
  }, [isRapid, isLookalike, pickLookalike, PER_ROUND_TIME]);


  const finish = useCallback((finalScore: number, finalStreak: number) => {
    setOver(true);
    sfx.gameOver();
    const updated = { ...profile };
    updated.bestStreak = Math.max(updated.bestStreak, finalStreak);
    const prevLvl = levelFromXp(updated.xp).level;
    updated.xp += finalScore * 2;
    const newLvl = levelFromXp(updated.xp).level;
    const earned = grantAchievements(updated, { streak: finalStreak, lvl: newLvl, score: finalScore });
    if (newLvl > prevLvl) sfx.levelUp();
    saveProfile(updated);
    saveScore({ username: updated.username, avatar: updated.avatar, score: finalScore, mode: MODE_LABEL, date: Date.now() });
    setProfile(updated);
    setNewAchievements(earned);
  }, [profile, grantAchievements]);

  const handleWrong = useCallback((kind: "wrong" | "timeout") => {
    sfx.wrong();
    setFeedback(kind);
    setBurstColor("destructive");
    setBurst((n) => n + 1);
    setStreak(0);
    if (kind === "wrong") setWrongs((n) => n + 1);
    setFactShown({ country });
    const newLives = isRapid ? lives : lives - 1;
    if (!isRapid) setLives(newLives);
    const newPlayed = profile.totalPlayed + 1;
    const updated = { ...profile, totalPlayed: newPlayed };
    setProfile(updated);
    saveProfile(updated);
    const delay = isRapid ? 700 : 1800;
    setTimeout(() => {
      setFactShown(null);
      if (isRapid) {
        if (round >= TOTAL_ROUNDS || time <= 0) finish(score, streak);
        else { setRound((r) => r + 1); nextRound(); }
      } else {
        if (newLives <= 0) finish(score, streak);
        else if (round >= TOTAL_ROUNDS) finish(score, streak);
        else { setRound((r) => r + 1); nextRound(); }
      }
    }, delay);
  }, [country, lives, profile, score, streak, round, finish, nextRound, isRapid, time, TOTAL_ROUNDS]);

  const handleCorrect = useCallback(() => {
    sfx.correct();
    if (streak + 1 >= 3) sfx.combo();
    setFeedback("correct");
    setBurstColor("success");
    setBurst((n) => n + 1);
    const base = 10;
    const timeBonus = Math.round(time * 0.5);
    const earned = Math.max(2, Math.round((base + timeBonus) * multiplier));
    setRecentXP({ amount: earned, key: Date.now() });
    const newScore = score + earned;
    const newStreak = streak + 1;
    setScore(newScore);
    setStreak(newStreak);
    setFactShown({ country });
    const newCorrect = profile.totalCorrect + 1;
    const newPlayed = profile.totalPlayed + 1;
    const updated = { ...profile, totalCorrect: newCorrect, totalPlayed: newPlayed };
    setProfile(updated);
    saveProfile(updated);
    const delay = isRapid ? 600 : 1500;
    setTimeout(() => {
      setFactShown(null);
      if (round >= TOTAL_ROUNDS || (isRapid && time <= 0)) finish(newScore, newStreak);
      else { setRound((r) => r + 1); nextRound(); }
    }, delay);
  }, [streak, time, multiplier, score, profile, country, round, finish, nextRound, isRapid, TOTAL_ROUNDS]);

  const handleSkip = useCallback(() => {
    if (over || feedback) return;
    sfx.click();
    setSkips((n) => n + 1);
    setStreak(0);
    if (round >= TOTAL_ROUNDS) finish(score, streak);
    else { setRound((r) => r + 1); nextRound(); }
  }, [over, feedback, round, TOTAL_ROUNDS, finish, score, streak, nextRound]);

  // timer — classic resets each round; rapid is a single shared 10s clock
  useEffect(() => {
    if (over) return;
    if (!isRapid && feedback) return;
    if (time <= 0) {
      if (isRapid) finish(score, streak);
      else handleWrong("timeout");
      return;
    }
    const id = setTimeout(() => {
      setTime((t) => t - 1);
      if (time <= 3) sfx.tick();
    }, 1000);
    return () => clearTimeout(id);
  }, [time, over, feedback, handleWrong, isRapid, finish, score, streak]);

  const pickOption = (c: Country) => {
    if (over || feedback) return;
    sfx.click();
    setPicked(c.name);
    if (c.name === country.name) handleCorrect();
    else handleWrong("wrong");
  };

  if (over) return <GameOver score={score} streak={streak} profile={profile} achievements={newAchievements} onExit={onExit} onRestart={() => location.reload()} />;

  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (time / PER_ROUND_TIME) * circumference;
  const timerColor = time <= 2 ? "var(--destructive)" : time <= 4 ? "var(--warning)" : "var(--success)";
  const timerTextColor = time <= 2 ? "text-destructive" : "text-foreground";


  return (
    <div className="relative min-h-screen bg-[#070a1f] text-white overflow-hidden">
      <GameBackdrop />
      <FloatingFlags />

      <div className="relative mx-auto w-full max-w-2xl px-4 py-6 sm:py-10">
        <ParticleBurst trigger={burst} color={burstColor} />

        {/* HUD */}
        <div className="mb-6 flex items-center justify-between gap-2 text-sm">
          <button
            onClick={() => { sfx.click(); onExit(); }}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white/5 border border-white/15 backdrop-blur-md hover:bg-white/15 hover:scale-105 transition"
            aria-label="Exit"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="flex flex-1 items-center justify-end gap-2 sm:gap-2.5">
            <HudChip icon={<Trophy className="h-3.5 w-3.5 text-amber-300" />} value={score} label="Score" tone="amber" />
            <HudChip
              icon={<Flame className={`h-3.5 w-3.5 ${streak >= 3 ? "text-orange-300" : "text-slate-400"}`} />}
              value={streak}
              label={`x${multiplier.toFixed(1)}`}
              tone="orange"
              pulse={streak >= 3}
            />
            {isRapid
              ? <HudChip icon={<span>⏭</span>} value={skips} label="Skips" tone="rose" />
              : <HudChip icon={<span>❤️</span>} value={lives} label="Lives" tone="rose" />
            }
            <HudChip icon={<span className="text-sky-300 font-black">#</span>} value={`${round}/${TOTAL_ROUNDS}`} label="Round" tone="sky" />
          </div>
        </div>

        {/* Combo banner */}
        {streak >= 3 && !feedback && (
          <div className="mb-4 flex justify-center animate-slide-up">
            <div className="relative flex items-center gap-2 rounded-full bg-gradient-to-r from-orange-500 via-amber-400 to-orange-500 px-5 py-1.5 text-slate-900 font-black text-sm uppercase tracking-wider shadow-[0_8px_30px_-5px_rgba(251,146,60,0.7)]">
              <span className="absolute inset-0 rounded-full bg-amber-300 blur-lg opacity-60 -z-10 animate-pulse" />
              🔥 {streak} Combo · x{multiplier.toFixed(1)} XP
            </div>
          </div>
        )}

        {/* Timer */}
        <div className="mb-6 flex justify-center">
          <div className={`relative h-[150px] w-[150px] rounded-full ${time <= 3 ? "animate-pulse" : ""}`}>
            {/* outer glow ring */}
            <div
              className="absolute inset-0 rounded-full blur-xl opacity-70 transition-colors"
              style={{ background: `radial-gradient(circle, ${timerColor}, transparent 70%)` }}
            />
            {/* tick marks */}
            <svg className="absolute inset-0 h-full w-full" viewBox="0 0 120 120">
              {Array.from({ length: 60 }).map((_, i) => {
                const angle = (i / 60) * 2 * Math.PI - Math.PI / 2;
                const r1 = 56, r2 = i % 5 === 0 ? 50 : 53;
                const x1 = 60 + Math.cos(angle) * r1;
                const y1 = 60 + Math.sin(angle) * r1;
                const x2 = 60 + Math.cos(angle) * r2;
                const y2 = 60 + Math.sin(angle) * r2;
                return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="rgba(255,255,255,0.18)" strokeWidth={i % 5 === 0 ? 1.5 : 0.8} />;
              })}
            </svg>
            {/* progress arc */}
            <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 120 120">
              <circle cx="60" cy="60" r={radius} stroke="rgba(255,255,255,0.08)" strokeWidth="6" fill="none" />
              <circle
                cx="60" cy="60" r={radius}
                stroke={timerColor}
                strokeWidth="6"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-1000 ease-linear"
                style={{ filter: `drop-shadow(0 0 8px ${timerColor})` }}
              />
            </svg>
            {/* sweeping hand */}
            <div
              className="absolute left-1/2 top-1/2 h-[60px] w-[2px] origin-bottom -translate-x-1/2 -translate-y-full bg-gradient-to-t from-transparent to-white/80 transition-transform duration-1000 ease-linear"
              style={{ transform: `translateX(-50%) translateY(-100%) rotate(${(1 - time / PER_ROUND_TIME) * 360}deg)` }}
            />
            {/* center hub */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-3 w-3 rounded-full bg-white shadow-[0_0_8px_white]" />
            {/* number */}
            <div className="absolute inset-0 flex items-center justify-center">
              <span
                key={time}
                className={`text-5xl font-black tabular-nums ${timerTextColor} animate-pop`}
                style={{ fontFamily: "var(--font-display)", textShadow: `0 0 24px ${timerColor}` }}
              >
                {time}
              </span>
            </div>
          </div>
        </div>

        {isRapid && (
          <div className="mb-4 flex items-center justify-center gap-3">
            <span className="text-[11px] font-black uppercase tracking-[0.25em] text-amber-300">⚡ Rapid Fire · Skip Allowed</span>
            <button
              onClick={handleSkip}
              disabled={!!feedback}
              className="flex items-center gap-1.5 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-40 border border-white/20 px-3 py-1.5 text-xs font-black uppercase tracking-wider transition"
            >
              <SkipForward className="h-3.5 w-3.5" /> Skip
            </button>
          </div>
        )}

        {/* Flag card — glassmorphism passport style */}
        <div className={`relative rounded-3xl bg-white/[0.06] border border-white/15 backdrop-blur-xl p-8 sm:p-12 text-center overflow-hidden shadow-[0_30px_80px_-20px_rgba(56,189,248,0.4)] ${feedback === "wrong" || feedback === "timeout" ? "animate-shake" : ""}`}>
          {/* gradient sheen */}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-sky-500/10 via-transparent to-violet-500/10" />
          {/* passport stamp corner */}
          <div className="absolute top-3 left-3 rotate-[-12deg] rounded border-2 border-dashed border-amber-300/50 px-2 py-0.5 text-[9px] font-mono font-black tracking-[0.2em] text-amber-200/80">
            MYSTERY · MAPS
          </div>
          <div className="absolute top-3 right-3 rounded border-2 border-dashed border-sky-300/40 px-2 py-0.5 text-[9px] font-mono font-black tracking-[0.2em] text-sky-200/70">
            ROUND · {String(round).padStart(2, "0")}
          </div>

          {/* "Identify me" badge */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-amber-300 to-orange-400 text-slate-900 px-4 py-1 text-[10px] font-black uppercase tracking-[0.25em] shadow-lg shadow-amber-500/30">
            Identify Me
          </div>

          <div className="pointer-events-none absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.6) 1px, transparent 1px)", backgroundSize: "16px 16px" }} />

          <div className="relative pt-2">
            <div className="relative mx-auto w-fit" key={country.code}>
              {/* glow behind flag */}
              <div className="absolute inset-0 rounded-md bg-sky-400/40 blur-2xl scale-110 -z-10" />
              <img
                src={country.flag}
                alt="Country flag"
                draggable={false}
                className="h-32 sm:h-44 w-auto rounded-md ring-1 ring-white/30 shadow-[0_20px_50px_-10px_rgba(0,0,0,0.6)] select-none animate-pop transition hover:scale-105 hover:rotate-1"
              />
              {/* corner marks */}
              <span className="absolute -top-1 -left-1 h-3 w-3 border-t-2 border-l-2 border-amber-300/80" />
              <span className="absolute -top-1 -right-1 h-3 w-3 border-t-2 border-r-2 border-amber-300/80" />
              <span className="absolute -bottom-1 -left-1 h-3 w-3 border-b-2 border-l-2 border-amber-300/80" />
              <span className="absolute -bottom-1 -right-1 h-3 w-3 border-b-2 border-r-2 border-amber-300/80" />
            </div>
            <p className="mt-6 text-[11px] font-black uppercase tracking-[0.3em] text-sky-200/80">
              Which country flies this flag?
            </p>
          </div>
        </div>

        {/* Fact / feedback popup */}
        {factShown && (
          <div className={`mt-4 rounded-2xl border backdrop-blur-md p-4 animate-slide-up ${feedback === "correct" ? "bg-emerald-500/15 border-emerald-400/50 shadow-[0_0_30px_-5px_rgba(52,211,153,0.5)]" : "bg-rose-500/15 border-rose-400/50 shadow-[0_0_30px_-5px_rgba(244,63,94,0.5)]"}`}>
            <div className="flex items-center gap-2 text-sm font-black uppercase tracking-wider">
              {feedback === "correct" ? <span className="text-emerald-300">✓ Correct!</span> : feedback === "timeout" ? <span className="text-rose-300">⏱ Out of Time</span> : <span className="text-rose-300">✗ Wrong!</span>}
              <span className="text-white">— {factShown.country.name}</span>
            </div>
            <p className="mt-1 text-sm text-slate-200/90">💡 {factShown.country.fact}</p>
          </div>
        )}

        {/* Options */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3 relative">
          {options.map((opt, i) => {
            const isCorrect = opt.name === country.name;
            const isPicked = picked === opt.name;
            const showState = !!feedback;
            const accents = [
              "from-sky-500/30 to-sky-500/5 hover:from-sky-400/50 ring-sky-400/40",
              "from-violet-500/30 to-violet-500/5 hover:from-violet-400/50 ring-violet-400/40",
              "from-emerald-500/30 to-emerald-500/5 hover:from-emerald-400/50 ring-emerald-400/40",
              "from-amber-500/30 to-amber-500/5 hover:from-amber-400/50 ring-amber-400/40",
            ];
            const cls = showState
              ? isCorrect
                ? "bg-gradient-to-br from-emerald-400/60 to-emerald-600/30 ring-2 ring-emerald-300 shadow-[0_0_40px_-5px_rgba(52,211,153,0.7)]"
                : isPicked
                ? "bg-gradient-to-br from-rose-500/60 to-rose-700/30 ring-2 ring-rose-300 shadow-[0_0_40px_-5px_rgba(244,63,94,0.6)]"
                : "bg-white/[0.03] ring-1 ring-white/10 opacity-40"
              : `bg-gradient-to-br ${accents[i % 4]} ring-1 hover:scale-[1.02] hover:-translate-y-0.5 hover:shadow-[0_15px_40px_-10px_rgba(56,189,248,0.4)] active:scale-[0.98]`;
            return (
              <button
                key={opt.code}
                onClick={() => pickOption(opt)}
                disabled={!!feedback}
                className={`group relative overflow-hidden rounded-2xl backdrop-blur-md px-5 py-5 text-left font-black uppercase tracking-tight transition-all duration-300 ${cls}`}
              >
                {/* shimmer */}
                <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent group-hover:translate-x-full transition-transform duration-700" />
                <div className="relative flex items-center gap-3">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/10 ring-1 ring-white/20 text-[11px] font-black text-white/80">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="text-base sm:text-lg">{opt.name}</span>
                  {showState && isCorrect && <span className="ml-auto text-emerald-200">✓</span>}
                  {showState && isPicked && !isCorrect && <span className="ml-auto text-rose-200">✗</span>}
                </div>
              </button>
            );
          })}
          {recentXP && (
            <span
              key={recentXP.key}
              className="pointer-events-none absolute -top-8 right-2 text-lg font-black text-amber-300 animate-slide-up"
              style={{ textShadow: "0 0 20px rgba(251,191,36,0.9)" }}
            >
              +{recentXP.amount} XP
            </span>
          )}
        </div>

        {/* Level bar */}
        <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.04] backdrop-blur-md p-3 text-xs">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 font-black uppercase tracking-wider">
              <span className="flex h-6 w-6 items-center justify-center rounded-md bg-gradient-to-br from-amber-300 to-orange-400 text-slate-900 text-[10px]">
                {lvl.level}
              </span>
              Level {lvl.level}
            </span>
            <span className="text-slate-300/80 tabular-nums">{lvl.xpInto}/{lvl.xpNeeded} XP</span>
          </div>
          <div className="relative mt-2 h-2 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full bg-gradient-to-r from-amber-300 via-orange-400 to-pink-500 transition-all duration-500"
              style={{ width: `${lvl.progress * 100}%`, boxShadow: "0 0 12px rgba(251,191,36,0.7)" }}
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full animate-[shimmer_2s_linear_infinite]" style={{ animation: "none" }} />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- HUD chip ---------- */
function HudChip({ icon, value, label, tone, pulse }: { icon: React.ReactNode; value: React.ReactNode; label: string; tone: "amber" | "orange" | "rose" | "sky"; pulse?: boolean }) {
  const tones = {
    amber: "from-amber-400/20 to-amber-600/5 ring-amber-300/30",
    orange: "from-orange-400/20 to-orange-600/5 ring-orange-300/30",
    rose: "from-rose-400/20 to-rose-600/5 ring-rose-300/30",
    sky: "from-sky-400/20 to-sky-600/5 ring-sky-300/30",
  } as const;
  return (
    <div className={`flex items-center gap-1.5 rounded-full bg-gradient-to-br ${tones[tone]} ring-1 backdrop-blur-md px-3 py-1.5 ${pulse ? "animate-pulse" : ""}`}>
      {icon}
      <span className="font-black tabular-nums text-white">{value}</span>
      <span className="text-white/60 text-[10px] uppercase tracking-wider">{label}</span>
    </div>
  );
}

/* ---------- Animated backdrop ---------- */
function GameBackdrop() {
  return (
    <>
      <div className="pointer-events-none fixed inset-0 opacity-[0.06]" style={{ backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.9) 1px, transparent 1px)", backgroundSize: "26px 26px" }} />
      <div className="pointer-events-none fixed -top-32 -left-32 h-[480px] w-[480px] rounded-full bg-sky-500/25 blur-[100px] animate-glow-pulse" />
      <div className="pointer-events-none fixed -bottom-40 -right-32 h-[520px] w-[520px] rounded-full bg-violet-600/25 blur-[110px] animate-glow-pulse" style={{ animationDelay: "1.5s" }} />
      <div className="pointer-events-none fixed top-1/3 left-1/2 -translate-x-1/2 h-[400px] w-[700px] rounded-full bg-amber-500/10 blur-[120px]" />
      {/* Twinkling particles */}
      <div className="pointer-events-none fixed inset-0">
        {Array.from({ length: 30 }).map((_, i) => {
          const top = (i * 41) % 100;
          const left = (i * 67) % 100;
          const size = (i % 3) + 1;
          return (
            <span
              key={i}
              className="absolute rounded-full bg-white animate-twinkle"
              style={{
                top: `${top}%`,
                left: `${left}%`,
                width: `${size}px`,
                height: `${size}px`,
                animationDelay: `${(i % 6) * 0.5}s`,
                opacity: 0.5,
              }}
            />
          );
        })}
      </div>
    </>
  );
}

const FLOATING_GAME_FLAGS = ["jp", "br", "fr", "de", "us", "in"] as const;
function FloatingFlags() {
  const positions = [
    "top-[8%] left-[3%] w-12 rotate-[-12deg]",
    "top-[14%] right-[4%] w-14 rotate-[8deg]",
    "top-[55%] left-[2%] w-12 rotate-[6deg]",
    "top-[60%] right-[3%] w-14 rotate-[-10deg]",
    "bottom-[8%] left-[6%] w-10 rotate-[-6deg]",
    "bottom-[12%] right-[6%] w-12 rotate-[10deg]",
  ];
  return (
    <div className="pointer-events-none fixed inset-0 hidden sm:block">
      {FLOATING_GAME_FLAGS.map((c, i) => (
        <img
          key={c}
          src={`https://flagcdn.com/w80/${c}.png`}
          alt=""
          loading="lazy"
          className={`absolute rounded shadow-2xl ring-1 ring-white/20 opacity-30 animate-float blur-[0.5px] ${positions[i]}`}
          style={{ animationDelay: `${i * 0.7}s` }}
        />
      ))}
    </div>
  );
}


function GameOver({ score, streak, profile, achievements, onExit, onRestart }: {
  score: number; streak: number; profile: Profile; achievements: string[]; onExit: () => void; onRestart: () => void;
}) {
  const lvl = levelFromXp(profile.xp);
  const share = () => {
    const text = `🌍 I scored ${score} on Mystery Maps with a ${streak}-streak! Can you beat me?`;
    if (navigator.share) navigator.share({ title: "Mystery Maps", text, url: location.href }).catch(() => {});
    else { navigator.clipboard.writeText(`${text} ${location.href}`); alert("Copied to clipboard!"); }
  };
  return (
    <div className="mx-auto w-full max-w-lg px-4 py-10 animate-slide-up">
      <div className="rounded-3xl bg-gradient-card border border-border p-8 text-center shadow-card glow-primary">
        <div className="text-6xl animate-pop">🏆</div>
        <h2 className="mt-3 text-3xl font-bold text-gradient-primary">Run Complete</h2>
        <p className="text-muted-foreground text-sm">Classic mode</p>
        <div className="mt-6 grid grid-cols-3 gap-3">
          <Box label="Score" value={score} />
          <Box label="Best Streak" value={streak} />
          <Box label="Level" value={lvl.level} />
        </div>
        {achievements.length > 0 && (
          <div className="mt-6 rounded-2xl border border-primary/40 bg-primary/10 p-4">
            <p className="text-xs uppercase tracking-widest text-primary font-bold">New Achievements</p>
            <div className="mt-2 flex flex-wrap justify-center gap-2">
              {achievements.map((a) => (
                <span key={a} className="rounded-full bg-card px-3 py-1.5 text-sm">
                  {ACHIEVEMENTS[a].icon} {ACHIEVEMENTS[a].name}
                </span>
              ))}
            </div>
          </div>
        )}
        <div className="mt-6 flex gap-2">
          <Button onClick={onExit} variant="outline" className="flex-1 h-12 rounded-xl">Home</Button>
          <Button onClick={share} variant="outline" className="flex-1 h-12 rounded-xl">Share</Button>
          <Button onClick={onRestart} className="flex-1 h-12 rounded-xl bg-gradient-primary text-primary-foreground glow-primary"><Zap className="mr-1 h-4 w-4" />Play Again</Button>
        </div>
      </div>
    </div>
  );
}

function Box({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-card border border-border p-3">
      <div className="text-2xl font-bold tabular-nums">{value}</div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
    </div>
  );
}
