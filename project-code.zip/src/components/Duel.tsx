import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { COUNTRIES, getCountryPool, type Country, type Difficulty } from "@/lib/countries";
import { sfx } from "@/lib/sounds";
import { loadProfile } from "@/lib/game-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Copy, X, Swords, Trophy, Zap, Users, Loader2, Check, ArrowLeft } from "lucide-react";

/* ============================================================
   Duel Mode — realtime 1v1 via Supabase broadcast channels
   ============================================================ */

type DuelDifficulty = "easy" | "medium" | "hard" | "mixed";
const Q_COUNTS = [5, 10, 15, 20] as const;
const DIFFS: { id: DuelDifficulty; label: string; emoji: string }[] = [
  { id: "easy", label: "Easy", emoji: "🌱" },
  { id: "medium", label: "Medium", emoji: "⚡" },
  { id: "hard", label: "Hard", emoji: "🔥" },
  { id: "mixed", label: "Mixed", emoji: "🎲" },
];
const PER_Q_TIME = 12;

type Question = { code: string; correct: string; options: string[] };
type Player = { id: string; name: string; avatar: string; isHost: boolean };
type Phase = "lobby" | "waiting" | "countdown" | "playing" | "over";

function randCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 5; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function diffToCorePool(d: DuelDifficulty): Country[] {
  if (d === "easy") return getCountryPool("beginner");
  if (d === "medium") return getCountryPool("intermediate");
  if (d === "hard") return getCountryPool("advanced");
  return COUNTRIES;
}

function genQuestions(d: DuelDifficulty, n: number): Question[] {
  const pool = diffToCorePool(d);
  const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, n);
  return shuffled.map((c) => {
    const distractors = pool.filter((x) => x.code !== c.code).sort(() => Math.random() - 0.5).slice(0, 3);
    const options = [c, ...distractors].sort(() => Math.random() - 0.5).map((x) => x.name);
    return { code: c.code, correct: c.name, options };
  });
}

export function Duel({ onExit }: { onExit: () => void }) {
  const profile = useRef(loadProfile()).current;
  const meRef = useRef<Player>({
    id: Math.random().toString(36).slice(2, 10),
    name: profile.username || "Player",
    avatar: profile.avatar || "🦊",
    isHost: false,
  });

  const [phase, setPhase] = useState<Phase>("lobby");
  const [mode, setMode] = useState<"choose" | "create" | "join">("choose");
  const [code, setCode] = useState("");
  const [joinInput, setJoinInput] = useState("");
  const [qCount, setQCount] = useState<number>(10);
  const [difficulty, setDifficulty] = useState<DuelDifficulty>("medium");
  const [players, setPlayers] = useState<Player[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [qIdx, setQIdx] = useState(0);
  const [scores, setScores] = useState<Record<string, number>>({});
  const [picked, setPicked] = useState<string | null>(null);
  const [firstCorrect, setFirstCorrect] = useState<{ playerId: string; ts: number; bonus: number } | null>(null);
  const [answered, setAnswered] = useState<Set<string>>(new Set());
  const [countdown, setCountdown] = useState(3);
  const [time, setTime] = useState(PER_Q_TIME);
  const [error, setError] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);

  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const qStartRef = useRef<number>(0);

  const me = meRef.current;
  const opponent = players.find((p) => p.id !== me.id);
  const meScore = scores[me.id] ?? 0;
  const oppScore = opponent ? scores[opponent.id] ?? 0 : 0;
  const currentQ = questions[qIdx];

  // ---------- Channel setup ----------
  const setupChannel = useCallback(async (roomCode: string, asHost: boolean) => {
    setConnecting(true);
    setError(null);
    meRef.current.isHost = asHost;
    const ch = supabase.channel(`duel:${roomCode}`, {
      config: { broadcast: { self: true, ack: true }, presence: { key: meRef.current.id } },
    });

    ch.on("presence", { event: "sync" }, () => {
      const state = ch.presenceState() as Record<string, Array<Player>>;
      const all: Player[] = [];
      for (const key of Object.keys(state)) {
        const meta = state[key][0];
        if (meta) all.push(meta);
      }
      if (!asHost && all.length > 2) {
        setError("Room is full");
        ch.unsubscribe();
        return;
      }
      setPlayers(all);
    });

    ch.on("broadcast", { event: "start" }, ({ payload }) => {
      setQuestions(payload.questions);
      setQCount(payload.questions.length);
      setDifficulty(payload.difficulty);
      setScores({});
      setQIdx(0);
      setPicked(null);
      setFirstCorrect(null);
      setAnswered(new Set());
      setCountdown(3);
      setPhase("countdown");
      sfx.click();
    });

    ch.on("broadcast", { event: "answer" }, ({ payload }) => {
      const { playerId, qIdx: idx, correct, ts } = payload as {
        playerId: string; qIdx: number; correct: boolean; ts: number;
      };
      setAnswered((prev) => {
        const next = new Set(prev);
        next.add(playerId);
        return next;
      });
      if (correct) {
        setFirstCorrect((prev) => {
          if (prev) return prev;
          const elapsed = Math.max(0, (ts - qStartRef.current) / 1000);
          const bonus = Math.max(2, Math.round((PER_Q_TIME - elapsed) * 1.5));
          const points = 10 + bonus;
          setScores((s) => ({ ...s, [playerId]: (s[playerId] ?? 0) + points }));
          if (playerId === meRef.current.id) sfx.correct();
          else sfx.wrong();
          return { playerId, ts, bonus };
        });
      } else if (playerId === meRef.current.id) {
        sfx.wrong();
      }
      // Tag for current question
      void idx;
    });

    ch.on("broadcast", { event: "next" }, ({ payload }) => {
      const { idx, isEnd } = payload as { idx: number; isEnd: boolean };
      if (isEnd) {
        setPhase("over");
        sfx.gameOver();
      } else {
        setQIdx(idx);
        setPicked(null);
        setFirstCorrect(null);
        setAnswered(new Set());
        setTime(PER_Q_TIME);
        qStartRef.current = Date.now();
      }
    });

    ch.on("broadcast", { event: "exit" }, ({ payload }) => {
      if (payload.playerId !== meRef.current.id) {
        setError("Opponent left the duel");
      }
    });

    await ch.subscribe(async (status) => {
      if (status === "SUBSCRIBED") {
        await ch.track({ ...meRef.current });
        setConnecting(false);
      }
    });

    channelRef.current = ch;
  }, []);

  // ---------- Actions ----------
  const createRoom = () => {
    const c = randCode();
    setCode(c);
    setMode("create");
    setPhase("waiting");
    setupChannel(c, true);
  };

  const joinRoom = () => {
    const c = joinInput.trim().toUpperCase();
    if (c.length < 4) { setError("Enter a valid room code"); return; }
    setCode(c);
    setMode("join");
    setPhase("waiting");
    setupChannel(c, false);
  };

  const startDuel = () => {
    if (!channelRef.current || players.length < 2) return;
    const qs = genQuestions(difficulty, qCount);
    channelRef.current.send({
      type: "broadcast",
      event: "start",
      payload: { questions: qs, difficulty, qCount },
    });
  };

  const submitAnswer = (option: string) => {
    if (picked || !currentQ) return;
    sfx.click();
    setPicked(option);
    const correct = option === currentQ.correct;
    channelRef.current?.send({
      type: "broadcast",
      event: "answer",
      payload: { playerId: me.id, qIdx, correct, ts: Date.now(), option },
    });
  };

  const advance = useCallback(() => {
    if (!me.isHost || !channelRef.current) return;
    const isEnd = qIdx + 1 >= questions.length;
    channelRef.current.send({
      type: "broadcast",
      event: "next",
      payload: { idx: qIdx + 1, isEnd },
    });
  }, [me.isHost, qIdx, questions.length]);

  const exitDuel = () => {
    channelRef.current?.send({
      type: "broadcast",
      event: "exit",
      payload: { playerId: me.id },
    });
    channelRef.current?.unsubscribe();
    channelRef.current = null;
    onExit();
  };

  // ---------- Effects ----------
  // Countdown -> playing
  useEffect(() => {
    if (phase !== "countdown") return;
    if (countdown <= 0) {
      setPhase("playing");
      setTime(PER_Q_TIME);
      qStartRef.current = Date.now();
      return;
    }
    sfx.tick();
    const id = setTimeout(() => setCountdown((c) => c - 1), 800);
    return () => clearTimeout(id);
  }, [phase, countdown]);

  // Per-question timer
  useEffect(() => {
    if (phase !== "playing") return;
    if (time <= 0) {
      // Host advances after a short reveal
      if (me.isHost) setTimeout(advance, 1200);
      return;
    }
    const id = setTimeout(() => setTime((t) => t - 1), 1000);
    return () => clearTimeout(id);
  }, [phase, time, me.isHost, advance]);

  // When both answered, host advances early
  useEffect(() => {
    if (phase !== "playing" || !me.isHost) return;
    if (answered.size >= players.length && players.length >= 2) {
      const id = setTimeout(advance, 1400);
      return () => clearTimeout(id);
    }
  }, [phase, answered, players.length, me.isHost, advance]);

  // Cleanup
  useEffect(() => {
    return () => {
      channelRef.current?.unsubscribe();
      channelRef.current = null;
    };
  }, []);

  // ---------- Render ----------
  return (
    <div className="relative min-h-screen overflow-hidden bg-[#05010f] text-white">
      <NeonGrid />
      <div className="relative mx-auto w-full max-w-4xl px-4 py-6 sm:py-10">
        <div className="mb-6 flex items-center justify-between">
          <button onClick={exitDuel} className="flex items-center gap-2 rounded-full bg-white/5 border border-white/15 px-4 py-2 text-sm font-bold hover:bg-white/10 transition">
            <ArrowLeft className="h-4 w-4" /> Exit
          </button>
          <div className="flex items-center gap-2 rounded-full border border-fuchsia-500/40 bg-fuchsia-500/10 px-4 py-2 text-xs font-black uppercase tracking-[0.25em] text-fuchsia-300">
            <Swords className="h-4 w-4" /> Duel Mode
          </div>
        </div>

        {error && (
          <div className="mb-4 rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">{error}</div>
        )}

        {phase === "lobby" && (
          <LobbyScreen
            mode={mode}
            setMode={setMode}
            joinInput={joinInput}
            setJoinInput={setJoinInput}
            qCount={qCount}
            setQCount={setQCount}
            difficulty={difficulty}
            setDifficulty={setDifficulty}
            onCreate={createRoom}
            onJoin={joinRoom}
          />
        )}

        {phase === "waiting" && (
          <WaitingScreen
            code={code}
            me={me}
            players={players}
            isHost={me.isHost}
            qCount={qCount}
            setQCount={setQCount}
            difficulty={difficulty}
            setDifficulty={setDifficulty}
            onStart={startDuel}
            connecting={connecting}
          />
        )}

        {phase === "countdown" && <CountdownScreen n={countdown} />}

        {phase === "playing" && currentQ && (
          <PlayScreen
            q={currentQ}
            qIdx={qIdx}
            total={questions.length}
            time={time}
            picked={picked}
            firstCorrect={firstCorrect}
            me={me}
            opponent={opponent}
            meScore={meScore}
            oppScore={oppScore}
            answered={answered}
            onPick={submitAnswer}
          />
        )}

        {phase === "over" && (
          <WinnerScreen
            me={me}
            opponent={opponent}
            meScore={meScore}
            oppScore={oppScore}
            onExit={exitDuel}
            onRematch={me.isHost ? () => {
              const qs = genQuestions(difficulty, qCount);
              setScores({});
              channelRef.current?.send({ type: "broadcast", event: "start", payload: { questions: qs, difficulty, qCount } });
            } : undefined}
          />
        )}
      </div>
    </div>
  );
}

/* ---------- Sub screens ---------- */

function LobbyScreen({
  mode, setMode, joinInput, setJoinInput, qCount, setQCount, difficulty, setDifficulty, onCreate, onJoin,
}: {
  mode: "choose" | "create" | "join";
  setMode: (m: "choose" | "create" | "join") => void;
  joinInput: string; setJoinInput: (s: string) => void;
  qCount: number; setQCount: (n: number) => void;
  difficulty: DuelDifficulty; setDifficulty: (d: DuelDifficulty) => void;
  onCreate: () => void; onJoin: () => void;
}) {
  return (
    <div className="space-y-8 animate-fade-in">
      <div className="text-center">
        <div className="inline-flex items-center gap-2 rounded-full bg-fuchsia-500/15 border border-fuchsia-400/40 px-4 py-1.5 text-xs font-black uppercase tracking-[0.3em] text-fuchsia-300">
          <Zap className="h-3.5 w-3.5" /> 1v1 Realtime
        </div>
        <h1 className="mt-4 text-5xl sm:text-6xl font-black tracking-tight">
          <span className="bg-gradient-to-r from-cyan-300 via-fuchsia-400 to-amber-300 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(217,70,239,0.5)]">
            DUEL ARENA
          </span>
        </h1>
        <p className="mt-3 text-white/70 max-w-md mx-auto">
          Challenge a friend. Fastest correct answer wins the round. Live scoring, neon vibes, zero mercy.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <NeonCard onClick={() => setMode("create")} active={mode === "create"} color="cyan" icon={<Swords className="h-7 w-7" />} title="Create Room" desc="Host a private match and invite your friend" />
        <NeonCard onClick={() => setMode("join")} active={mode === "join"} color="fuchsia" icon={<Users className="h-7 w-7" />} title="Join Room" desc="Enter a code to jump into a duel" />
      </div>

      {mode === "create" && (
        <div className="rounded-3xl border border-cyan-400/30 bg-cyan-500/5 p-6 backdrop-blur-md animate-slide-up">
          <h3 className="text-lg font-black mb-4 text-cyan-300">Round Settings</h3>
          <SettingsBlock qCount={qCount} setQCount={setQCount} difficulty={difficulty} setDifficulty={setDifficulty} />
          <Button onClick={onCreate} className="mt-6 w-full h-12 bg-gradient-to-r from-cyan-400 to-fuchsia-500 text-black font-black hover:opacity-90 text-base shadow-[0_10px_40px_-10px_rgba(34,211,238,0.7)]">
            CREATE ROOM
          </Button>
        </div>
      )}

      {mode === "join" && (
        <div className="rounded-3xl border border-fuchsia-400/30 bg-fuchsia-500/5 p-6 backdrop-blur-md animate-slide-up">
          <h3 className="text-lg font-black mb-4 text-fuchsia-300">Enter Room Code</h3>
          <Input
            value={joinInput}
            onChange={(e) => setJoinInput(e.target.value.toUpperCase())}
            placeholder="ABC12"
            maxLength={6}
            className="h-14 text-center text-3xl font-black tracking-[0.4em] bg-black/40 border-fuchsia-400/40 text-fuchsia-200 placeholder:text-fuchsia-200/30"
          />
          <Button onClick={onJoin} disabled={joinInput.length < 4} className="mt-4 w-full h-12 bg-gradient-to-r from-fuchsia-500 to-amber-400 text-black font-black hover:opacity-90 text-base shadow-[0_10px_40px_-10px_rgba(217,70,239,0.7)]">
            JOIN DUEL
          </Button>
        </div>
      )}
    </div>
  );
}

function SettingsBlock({ qCount, setQCount, difficulty, setDifficulty }: {
  qCount: number; setQCount: (n: number) => void; difficulty: DuelDifficulty; setDifficulty: (d: DuelDifficulty) => void;
}) {
  return (
    <div className="space-y-5">
      <div>
        <div className="text-xs font-black uppercase tracking-[0.2em] text-white/60 mb-2">Questions</div>
        <div className="grid grid-cols-4 gap-2">
          {Q_COUNTS.map((n) => (
            <button
              key={n}
              onClick={() => setQCount(n)}
              className={`h-14 rounded-xl font-black text-lg border-2 transition-all ${qCount === n ? "bg-gradient-to-br from-cyan-400 to-fuchsia-500 text-black border-white scale-105 shadow-[0_8px_30px_-5px_rgba(34,211,238,0.6)]" : "bg-white/5 border-white/15 hover:border-white/40"}`}
            >{n}</button>
          ))}
        </div>
      </div>
      <div>
        <div className="text-xs font-black uppercase tracking-[0.2em] text-white/60 mb-2">Difficulty</div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {DIFFS.map((d) => (
            <button
              key={d.id}
              onClick={() => setDifficulty(d.id)}
              className={`h-16 rounded-xl font-black border-2 transition-all flex flex-col items-center justify-center gap-0.5 ${difficulty === d.id ? "bg-gradient-to-br from-fuchsia-500 to-amber-400 text-black border-white scale-105 shadow-[0_8px_30px_-5px_rgba(217,70,239,0.6)]" : "bg-white/5 border-white/15 hover:border-white/40"}`}
            >
              <span className="text-xl">{d.emoji}</span>
              <span className="text-xs">{d.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function NeonCard({ onClick, active, color, icon, title, desc }: {
  onClick: () => void; active: boolean; color: "cyan" | "fuchsia"; icon: React.ReactNode; title: string; desc: string;
}) {
  const cyan = active ? "border-cyan-400 bg-cyan-400/10 shadow-[0_0_40px_-5px_rgba(34,211,238,0.5)]" : "border-cyan-400/20 hover:border-cyan-400/60";
  const fuc = active ? "border-fuchsia-400 bg-fuchsia-400/10 shadow-[0_0_40px_-5px_rgba(217,70,239,0.5)]" : "border-fuchsia-400/20 hover:border-fuchsia-400/60";
  return (
    <button onClick={onClick} className={`group relative rounded-3xl border-2 p-6 text-left transition-all ${color === "cyan" ? cyan : fuc}`}>
      <div className={`mb-3 flex h-14 w-14 items-center justify-center rounded-2xl ${color === "cyan" ? "bg-cyan-400/20 text-cyan-300" : "bg-fuchsia-400/20 text-fuchsia-300"}`}>
        {icon}
      </div>
      <div className="font-black text-xl">{title}</div>
      <div className="mt-1 text-sm text-white/60">{desc}</div>
    </button>
  );
}

function WaitingScreen({
  code, me, players, isHost, qCount, setQCount, difficulty, setDifficulty, onStart, connecting,
}: {
  code: string; me: Player; players: Player[]; isHost: boolean;
  qCount: number; setQCount: (n: number) => void; difficulty: DuelDifficulty; setDifficulty: (d: DuelDifficulty) => void;
  onStart: () => void; connecting: boolean;
}) {
  const opp = players.find((p) => p.id !== me.id);
  const ready = players.length >= 2;
  const copy = () => { navigator.clipboard.writeText(code); sfx.click(); };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="rounded-3xl border-2 border-cyan-400/30 bg-gradient-to-br from-cyan-500/10 to-fuchsia-500/10 p-8 text-center backdrop-blur-md">
        <div className="text-xs font-black uppercase tracking-[0.3em] text-cyan-300 mb-2">Room Code</div>
        <div className="flex items-center justify-center gap-3">
          <div className="font-black text-6xl sm:text-7xl tracking-[0.2em] bg-gradient-to-r from-cyan-300 to-fuchsia-400 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(34,211,238,0.5)]">
            {code}
          </div>
          <button onClick={copy} className="h-12 w-12 rounded-xl bg-white/10 border border-white/20 hover:bg-white/20 flex items-center justify-center transition" title="Copy">
            <Copy className="h-5 w-5" />
          </button>
        </div>
        <div className="mt-3 text-sm text-white/60">Share this code with your friend</div>
      </div>

      <div className="grid sm:grid-cols-[1fr_auto_1fr] gap-4 items-center">
        <PlayerSlot player={me} self />
        <div className="hidden sm:flex items-center justify-center">
          <div className="font-black text-3xl bg-gradient-to-br from-fuchsia-400 to-amber-300 bg-clip-text text-transparent">VS</div>
        </div>
        {opp ? <PlayerSlot player={opp} /> : <EmptySlot connecting={connecting} />}
      </div>

      {isHost && (
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <h3 className="text-sm font-black uppercase tracking-[0.2em] text-white/60 mb-4">Match Settings</h3>
          <SettingsBlock qCount={qCount} setQCount={setQCount} difficulty={difficulty} setDifficulty={setDifficulty} />
          <Button
            onClick={onStart}
            disabled={!ready}
            className="mt-6 w-full h-14 bg-gradient-to-r from-cyan-400 via-fuchsia-500 to-amber-400 text-black font-black text-lg disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_15px_50px_-10px_rgba(217,70,239,0.7)]"
          >
            {ready ? "⚔️  START DUEL" : "Waiting for opponent…"}
          </Button>
        </div>
      )}
      {!isHost && (
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 text-center">
          <Loader2 className="h-10 w-10 mx-auto animate-spin text-fuchsia-400" />
          <div className="mt-4 font-black text-lg">Waiting for host to start…</div>
          <div className="text-sm text-white/60 mt-1">{qCount} questions · {difficulty}</div>
        </div>
      )}
    </div>
  );
}

function PlayerSlot({ player, self }: { player: Player; self?: boolean }) {
  return (
    <div className={`rounded-3xl border-2 p-5 flex items-center gap-4 ${self ? "border-cyan-400/60 bg-cyan-400/10" : "border-fuchsia-400/60 bg-fuchsia-400/10"}`}>
      <div className="h-14 w-14 rounded-2xl bg-black/40 border border-white/20 flex items-center justify-center text-3xl">{player.avatar}</div>
      <div className="flex-1 min-w-0">
        <div className="font-black truncate">{player.name}{self && <span className="ml-2 text-xs text-cyan-300">(YOU)</span>}</div>
        <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-0.5">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" /> Connected
          {player.isHost && <span className="ml-2 text-amber-300">HOST</span>}
        </div>
      </div>
    </div>
  );
}

function EmptySlot({ connecting }: { connecting: boolean }) {
  return (
    <div className="rounded-3xl border-2 border-dashed border-white/15 p-5 flex items-center gap-4 bg-white/[0.02]">
      <div className="h-14 w-14 rounded-2xl bg-white/5 flex items-center justify-center">
        {connecting ? <Loader2 className="h-6 w-6 animate-spin text-white/40" /> : <Users className="h-6 w-6 text-white/30" />}
      </div>
      <div className="flex-1">
        <div className="font-black text-white/50">Waiting for opponent…</div>
        <div className="text-xs text-white/30 mt-0.5">They'll appear here when they join</div>
      </div>
    </div>
  );
}

function CountdownScreen({ n }: { n: number }) {
  return (
    <div className="flex items-center justify-center py-32">
      <div key={n} className="relative animate-pop">
        <div className="absolute inset-0 blur-3xl bg-gradient-to-br from-cyan-400 to-fuchsia-500 opacity-60" />
        <div className="relative text-[200px] font-black leading-none bg-gradient-to-br from-cyan-300 via-fuchsia-400 to-amber-300 bg-clip-text text-transparent drop-shadow-[0_0_60px_rgba(217,70,239,0.8)]">
          {n > 0 ? n : "GO!"}
        </div>
      </div>
    </div>
  );
}

function PlayScreen({
  q, qIdx, total, time, picked, firstCorrect, me, opponent, meScore, oppScore, answered, onPick,
}: {
  q: Question; qIdx: number; total: number; time: number;
  picked: string | null; firstCorrect: { playerId: string; ts: number; bonus: number } | null;
  me: Player; opponent: Player | undefined; meScore: number; oppScore: number;
  answered: Set<string>; onPick: (option: string) => void;
}) {
  const flagUrl = `https://flagcdn.com/w640/${q.code.toLowerCase()}.png`;
  const reveal = firstCorrect !== null || picked !== null;
  const timePct = (time / PER_Q_TIME) * 100;

  return (
    <div className="animate-fade-in space-y-5">
      {/* Score HUD */}
      <div className="grid grid-cols-[1fr_auto_1fr] gap-3 items-center">
        <PlayerScore player={me} score={meScore} answered={answered.has(me.id)} side="left" highlight={firstCorrect?.playerId === me.id} />
        <div className="text-center">
          <div className="text-xs font-black text-white/40 uppercase tracking-[0.2em]">Round</div>
          <div className="font-black text-2xl bg-gradient-to-br from-cyan-300 to-fuchsia-400 bg-clip-text text-transparent">{qIdx + 1}/{total}</div>
        </div>
        {opponent
          ? <PlayerScore player={opponent} score={oppScore} answered={answered.has(opponent.id)} side="right" highlight={firstCorrect?.playerId === opponent.id} />
          : <div className="rounded-2xl border border-white/10 p-3 text-center text-white/40 text-sm">Waiting…</div>}
      </div>

      {/* Timer bar */}
      <div className="relative h-2 rounded-full bg-white/5 overflow-hidden">
        <div
          className={`absolute inset-y-0 left-0 transition-all duration-1000 ease-linear ${time <= 3 ? "bg-gradient-to-r from-rose-500 to-orange-400" : "bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-amber-300"}`}
          style={{ width: `${timePct}%` }}
        />
      </div>

      {/* Flag */}
      <div className="relative rounded-3xl border-2 border-white/15 bg-gradient-to-br from-cyan-500/10 to-fuchsia-500/10 p-6 backdrop-blur-md overflow-hidden">
        <div className="absolute top-3 right-3 text-xs font-black tabular-nums text-white/60">{time}s</div>
        <div className="mx-auto max-w-md aspect-[4/3] rounded-2xl overflow-hidden border-4 border-black shadow-[0_20px_60px_-10px_rgba(34,211,238,0.5)]">
          <img src={flagUrl} alt="" className="h-full w-full object-cover" />
        </div>
        <div className="mt-4 text-center text-xs font-black uppercase tracking-[0.25em] text-white/60">Which country is this?</div>
      </div>

      {/* Options */}
      <div className="grid sm:grid-cols-2 gap-3">
        {q.options.map((opt, i) => {
          const isCorrect = opt === q.correct;
          const isPicked = picked === opt;
          let cls = "border-white/15 bg-white/5 hover:border-cyan-400/60 hover:bg-cyan-400/5";
          if (reveal) {
            if (isCorrect) cls = "border-emerald-400 bg-emerald-400/15 text-emerald-100 shadow-[0_0_30px_-5px_rgba(52,211,153,0.6)]";
            else if (isPicked) cls = "border-rose-400 bg-rose-400/15 text-rose-100";
            else cls = "border-white/10 bg-white/[0.02] opacity-50";
          } else if (isPicked) {
            cls = "border-cyan-400 bg-cyan-400/15 text-cyan-100";
          }
          return (
            <button
              key={i}
              onClick={() => onPick(opt)}
              disabled={!!picked || reveal}
              className={`group h-16 rounded-2xl border-2 font-black text-base transition-all px-4 flex items-center gap-3 ${cls} disabled:cursor-not-allowed`}
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-black/30 text-xs font-black text-white/70">{String.fromCharCode(65 + i)}</span>
              <span className="flex-1 text-left">{opt}</span>
              {reveal && isCorrect && <Check className="h-5 w-5 text-emerald-300" />}
              {reveal && isPicked && !isCorrect && <X className="h-5 w-5 text-rose-300" />}
            </button>
          );
        })}
      </div>

      {firstCorrect && (
        <div className="text-center animate-slide-up">
          <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-emerald-400 to-cyan-400 text-black px-5 py-2 font-black uppercase tracking-wider text-sm shadow-[0_10px_30px_-5px_rgba(52,211,153,0.6)]">
            <Zap className="h-4 w-4" />
            {firstCorrect.playerId === me.id ? "YOU" : opponent?.name ?? "Opponent"} got it first! +{10 + firstCorrect.bonus}
          </div>
        </div>
      )}
    </div>
  );
}

function PlayerScore({ player, score, answered, side, highlight }: {
  player: Player; score: number; answered: boolean; side: "left" | "right"; highlight: boolean;
}) {
  return (
    <div className={`rounded-2xl border-2 p-3 flex items-center gap-3 transition-all ${side === "left" ? "border-cyan-400/40 bg-cyan-400/5" : "border-fuchsia-400/40 bg-fuchsia-400/5"} ${highlight ? "scale-105 shadow-[0_0_30px_-5px_rgba(217,70,239,0.6)]" : ""}`}>
      <div className="h-11 w-11 rounded-xl bg-black/40 border border-white/20 flex items-center justify-center text-2xl shrink-0">{player.avatar}</div>
      <div className="flex-1 min-w-0">
        <div className="font-black text-sm truncate">{player.name}</div>
        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider">
          {answered ? <span className="text-emerald-400">● Answered</span> : <span className="text-white/40">○ Thinking…</span>}
        </div>
      </div>
      <div className="font-black text-2xl tabular-nums text-amber-300">{score}</div>
    </div>
  );
}

function WinnerScreen({ me, opponent, meScore, oppScore, onExit, onRematch }: {
  me: Player; opponent: Player | undefined; meScore: number; oppScore: number;
  onExit: () => void; onRematch?: () => void;
}) {
  const won = meScore > oppScore;
  const tie = meScore === oppScore;
  return (
    <div className="text-center py-10 animate-fade-in space-y-8">
      <div className="relative">
        <div className="absolute inset-0 blur-3xl opacity-60 bg-gradient-to-br from-amber-300 via-fuchsia-500 to-cyan-400" />
        <Trophy className="relative mx-auto h-24 w-24 text-amber-300 drop-shadow-[0_0_30px_rgba(251,191,36,0.8)]" />
      </div>
      <div>
        <div className="text-xs font-black uppercase tracking-[0.4em] text-white/50">Match Complete</div>
        <h1 className="mt-2 text-6xl sm:text-7xl font-black bg-gradient-to-br from-amber-300 via-fuchsia-400 to-cyan-300 bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(217,70,239,0.5)]">
          {tie ? "DRAW" : won ? "VICTORY" : "DEFEAT"}
        </h1>
      </div>

      <div className="grid grid-cols-[1fr_auto_1fr] gap-3 items-stretch max-w-2xl mx-auto">
        <FinalCard player={me} score={meScore} winner={won && !tie} />
        <div className="flex items-center font-black text-2xl text-white/40">VS</div>
        {opponent ? <FinalCard player={opponent} score={oppScore} winner={!won && !tie} /> : <div className="rounded-2xl border border-white/10 p-4 text-white/40">—</div>}
      </div>

      <div className="flex justify-center gap-3">
        {onRematch && (
          <Button onClick={onRematch} className="h-12 px-8 bg-gradient-to-r from-cyan-400 to-fuchsia-500 text-black font-black shadow-[0_10px_40px_-10px_rgba(34,211,238,0.7)]">
            REMATCH
          </Button>
        )}
        <Button onClick={onExit} variant="outline" className="h-12 px-8 bg-white/5 border-white/20 hover:bg-white/10 font-black">
          EXIT ARENA
        </Button>
      </div>
    </div>
  );
}

function FinalCard({ player, score, winner }: { player: Player; score: number; winner: boolean }) {
  return (
    <div className={`rounded-3xl border-2 p-5 ${winner ? "border-amber-400 bg-amber-400/10 shadow-[0_0_40px_-5px_rgba(251,191,36,0.6)]" : "border-white/15 bg-white/5"}`}>
      <div className="text-5xl mb-2">{player.avatar}</div>
      <div className="font-black truncate">{player.name}</div>
      <div className="mt-2 font-black text-4xl tabular-nums text-amber-300">{score}</div>
      {winner && <div className="mt-1 text-xs font-black uppercase tracking-wider text-amber-300">👑 Champion</div>}
    </div>
  );
}

/* ---------- Backdrop ---------- */
function NeonGrid() {
  return (
    <div className="pointer-events-none absolute inset-0 -z-0">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(34,211,238,0.18),transparent_50%),radial-gradient(circle_at_80%_30%,rgba(217,70,239,0.18),transparent_50%),radial-gradient(circle_at_50%_90%,rgba(251,191,36,0.12),transparent_50%)]" />
      <div
        className="absolute inset-0 opacity-[0.12]"
        style={{
          backgroundImage: "linear-gradient(rgba(34,211,238,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(217,70,239,0.5) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 80%)",
        }}
      />
    </div>
  );
}
