import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { LogOut } from "lucide-react";

export function AuthButton() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user ?? null);
    });
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    return () => subscription.unsubscribe();
  }, []);

  const signIn = async () => {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      console.error(result.error);
      setLoading(false);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  if (user) {
    const meta = (user.user_metadata ?? {}) as { avatar_url?: string; full_name?: string; name?: string };
    const name = meta.full_name || meta.name || user.email?.split("@")[0] || "Player";
    return (
      <div className="flex items-center gap-2">
        {meta.avatar_url ? (
          <img
            src={meta.avatar_url}
            alt={name}
            className="h-9 w-9 rounded-full ring-2 ring-yellow-400 object-cover"
          />
        ) : (
          <div className="h-9 w-9 rounded-full bg-yellow-400 text-black font-black flex items-center justify-center text-sm">
            {name[0]?.toUpperCase()}
          </div>
        )}
        <span className="hidden sm:inline text-sm font-semibold text-white/90 max-w-[8rem] truncate">{name}</span>
        <button
          onClick={signOut}
          aria-label="Sign out"
          className="h-9 w-9 flex items-center justify-center rounded-full bg-white/5 border border-white/15 hover:bg-white/10 transition"
        >
          <LogOut className="h-4 w-4 text-white/80" />
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={signIn}
      disabled={loading}
      className="flex items-center gap-2 rounded-full bg-white text-black px-3 sm:px-4 py-2 font-bold text-xs sm:text-sm border-2 border-black hover:shadow-[0_10px_30px_-8px_rgba(250,204,21,0.7)] hover:bg-yellow-50 transition shadow-md disabled:opacity-60"
    >
      <GoogleIcon className="h-4 w-4" />
      <span className="hidden sm:inline">{loading ? "Logging in…" : "Login"}</span>
      <span className="sm:hidden">{loading ? "…" : "Login"}</span>

    </button>
  );
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.6-6 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.3-.4-3.5z"/>
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35 26.7 36 24 36c-5.3 0-9.7-3.4-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/>
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4-4.1 5.3l6.2 5.2C41.3 35.6 44 30.3 44 24c0-1.3-.1-2.3-.4-3.5z"/>
    </svg>
  );
}
