import { useEffect, useState } from "react";
import { Game } from "./Game";
import { Duel } from "./Duel";
import { AuthButton } from "./AuthButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ACHIEVEMENTS,
  levelFromXp,
  loadLeaderboard,
  loadProfile,
  saveProfile,
  type LeaderboardEntry,
  type Profile,
} from "@/lib/game-store";
import { type Difficulty, type CategorySelection, type Continent } from "@/lib/countries";
import { sfx } from "@/lib/sounds";
import {
  Rocket,
  Play,
  ArrowLeft,
  ArrowRight,
  Moon,
  Sun,
  Globe2,
  Target,
  Trophy,
  Zap,
  Star,
  Heart,
  Plane,
  Compass,
  MapPin,
  Landmark,
  HelpCircle,
  Users,
  Flame,
} from "lucide-react";
import globeImg from "@/assets/globe.png";
import brainImg from "@/assets/brain-bulb.png";

type View = "home" | "setup" | "play" | "duel" | "options" | "achievements" | "leaderboard" | "profile" | "howto";

export type GameMode = "classic" | "rapid" | "lookalike";

const ROUND_OPTIONS = [10, 15, 20, 30] as const;
const DIFFICULTY_OPTIONS: { id: Difficulty; label: string; desc: string; emoji: string }[] = [
  { id: "beginner",     label: "Beginner",     desc: "Most popular flags",     emoji: "🌱" },
  { id: "intermediate", label: "Intermediate", desc: "Popular + mid-tier",     emoji: "🚀" },
  { id: "advanced",     label: "Advanced",     desc: "Lesser-known flags",     emoji: "🔥" },
  { id: "expert",       label: "Expert",       desc: "Obscure flags only",     emoji: "👑" },
];
const CONTINENTS: Continent[] = ["Africa", "Asia", "Europe", "North America", "South America", "Oceania"];

const FLOATING_FLAGS = [
  { code: "BR", className: "top-[4%] left-[2%] -rotate-12 w-20 sm:w-24" },
  { code: "JP", className: "top-[6%] right-[4%] rotate-6 w-20 sm:w-24" },
  { code: "DE", className: "top-[42%] left-[-2%] -rotate-6 w-20 sm:w-24" },
  { code: "FR", className: "top-[40%] right-[-2%] rotate-12 w-20 sm:w-24" },
];

const POPULAR_COUNTRIES = [
  { code: "IN", name: "India" },
  { code: "US", name: "United States" },
  { code: "BR", name: "Brazil" },
  { code: "DE", name: "Germany" },
  { code: "FR", name: "France" },
  { code: "JP", name: "Japan" },
  { code: "AU", name: "Australia" },
  { code: "GB", name: "United Kingdom" },
];

const FEATURES = [
  { icon: Globe2, color: "text-yellow-400", ring: "ring-yellow-500/30", glow: "bg-yellow-500/10", title: "Learn & Explore", desc: "Discover countries, flags and fascinating facts in a fun way." },
  { icon: Target, color: "text-yellow-400", ring: "ring-yellow-500/30", glow: "bg-yellow-500/10", title: "Challenge Yourself", desc: "Multiple game modes and difficulty levels to test your knowledge." },
  { icon: Trophy, color: "text-yellow-400", ring: "ring-yellow-500/30", glow: "bg-yellow-500/10", title: "Compete & Rank", desc: "Climb the leaderboard and become the ultimate flag expert." },
  { icon: Zap, color: "text-yellow-400", ring: "ring-yellow-500/30", glow: "bg-yellow-500/10", title: "Quick & Fun", desc: "Short quizzes perfect for a quick brain boost anytime!" },
];

const STATS = [
  { icon: Globe2, color: "text-yellow-400", value: "195+", label: "Countries", sub: "Explore the world" },
  { icon: Users, color: "text-yellow-400", value: "50K+", label: "Active Players", sub: "Worldwide community" },
  { icon: Trophy, color: "text-yellow-400", value: "10M+", label: "Games Played", sub: "And counting" },
  { icon: Flame, color: "text-yellow-400", value: "120", label: "Day Streaks", sub: "Keep it going!" },
];

// Deterministic seeded dot world map (no SSR hydration mismatch)
const DOT_MAP_URL = (() => {
  let s = 1337;
  const rnd = () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
  const circles = Array.from({ length: 520 })
    .map(() => `<circle cx='${Math.floor(rnd() * 1200)}' cy='${Math.floor(rnd() * 600)}' r='1.4'/>`)
    .join("");
  return (
    "data:image/svg+xml;utf8," +
    encodeURIComponent(
      `<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='600' viewBox='0 0 1200 600'><g fill='%23facc15' opacity='0.6'>${circles}</g></svg>`
    )
  );
})();

export function Home() {
  const [view, setView] = useState<View>("home");
  const [profile, setProfile] = useState<Profile>({ username: "Explorer", avatar: "🦊", xp: 0, totalCorrect: 0, totalPlayed: 0, bestStreak: 0, achievements: [], dailyStreak: 0 });
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [rounds, setRounds] = useState<number>(15);
  const [difficulty, setDifficulty] = useState<Difficulty>("beginner");
  const [mode, setMode] = useState<GameMode>("classic");
  const [category, setCategory] = useState<CategorySelection>({ kind: "general" });
  const [dark, setDark] = useState(true);

  useEffect(() => { setProfile(loadProfile()); }, []);
  useEffect(() => { setLeaderboard(loadLeaderboard()); }, [view]);

  const openSetup = () => { sfx.click(); setView("setup"); };
  const startGame = () => { sfx.click(); setView("play"); };

  if (view === "play") return (
    <Game settings={{ rounds, difficulty, mode, category }} onExit={() => { setView("home"); setProfile(loadProfile()); }} />
  );
  if (view === "duel") return <Duel onExit={() => setView("home")} />;

  return (
    <div className={dark ? "min-h-screen bg-black text-white" : "min-h-screen bg-white text-black"}>
      {/* Decorative background */}
      <BgPattern dark={dark} />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <NavBar
          dark={dark}
          onToggleDark={() => setDark((d) => !d)}
          onPlay={openSetup}
          onNav={(v) => { sfx.click(); setView(v); }}
        />

        {view === "home" && (
          <>
            <Hero onPlay={openSetup} onHowTo={() => setView("howto")} />
            <StatsRow />
            <FeatureRow />
            <Footer />
          </>
        )}

        {view === "setup" && (
          <SetupView
            rounds={rounds}
            difficulty={difficulty}
            category={category}
            mode={mode}
            onRounds={(n) => { sfx.click(); setRounds(n); }}
            onDifficulty={(d) => { sfx.click(); setDifficulty(d); }}
            onCategory={(c) => { sfx.click(); setCategory(c); }}
            onMode={(m) => { sfx.click(); setMode(m); }}
            onBack={() => setView("home")}
            onPlay={startGame}
          />
        )}

        {view === "options" && (
          <OptionsView
            rounds={rounds}
            difficulty={difficulty}
            onRounds={(n) => { sfx.click(); setRounds(n); }}
            onDifficulty={(d) => { sfx.click(); setDifficulty(d); }}
            onBack={() => setView("home")}
            onPlay={startGame}
          />
        )}

        {view === "howto" && (
          <PanelView title="How to Play" onBack={() => setView("home")}>
            <ol className="space-y-3 text-base font-semibold">
              {[
                "A flag appears with 4 options.",
                "Pick the right country before the timer hits zero.",
                "Build streaks for bonus XP and unlock achievements.",
                "Climb the leaderboard with your best score!",
              ].map((s, i) => (
                <li key={i} className="flex gap-3 items-start">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-yellow-400 text-black font-black">{i + 1}</span>
                  <span>{s}</span>
                </li>
              ))}
            </ol>
          </PanelView>
        )}

        {view === "achievements" && (
          <PanelView title="Achievements" onBack={() => setView("home")}>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {Object.entries(ACHIEVEMENTS).map(([k, a]) => {
                const has = profile.achievements.includes(k);
                return (
                  <div key={k} className={`rounded-2xl p-4 text-center border ${has ? "bg-yellow-500/20 border-yellow-400" : "bg-white/5 border-white/10 opacity-60"}`}>
                    <div className="text-3xl">{a.icon}</div>
                    <div className="text-sm font-bold mt-1">{a.name}</div>
                    <div className="text-xs opacity-80 mt-0.5">{a.desc}</div>
                  </div>
                );
              })}
            </div>
          </PanelView>
        )}

        {view === "leaderboard" && (
          <PanelView title="Leaderboard" onBack={() => setView("home")}>
            {leaderboard.length === 0 ? (
              <p className="p-8 text-center text-sm opacity-70">No scores yet — be the first!</p>
            ) : (
              <ol className="space-y-2">
                {leaderboard.slice(0, 20).map((e, i) => (
                  <li key={i} className="flex items-center gap-3 rounded-xl bg-white/5 border border-white/10 px-3 py-2">
                    <div className={`flex h-8 w-8 items-center justify-center rounded-lg font-black ${i === 0 ? "bg-yellow-400 text-black" : i === 1 ? "bg-white text-black" : i === 2 ? "bg-yellow-400 text-black" : "bg-white/10"}`}>
                      {i + 1}
                    </div>
                    <span className="text-xl">{e.avatar}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold truncate text-sm">{e.username}</div>
                      <div className="text-[10px] opacity-60">{e.mode}</div>
                    </div>
                    <div className="font-black tabular-nums">{e.score}</div>
                  </li>
                ))}
              </ol>
            )}
          </PanelView>
        )}

        {view === "profile" && (
          <ProfileView profile={profile} setProfile={(p) => { saveProfile(p); setProfile(p); }} onBack={() => setView("home")} />
        )}
      </div>
    </div>
  );
}

/* ---------- NavBar ---------- */

function NavBar({ dark, onToggleDark, onPlay, onNav }: { dark: boolean; onToggleDark: () => void; onPlay: () => void; onNav: (v: View) => void }) {
  return (
    <header className="flex items-center justify-between gap-4 py-5">
      <button onClick={() => onNav("home")} className="flex items-center gap-3 group">
        <div className="relative h-12 w-12 flex items-center justify-center rounded-2xl bg-gradient-to-br from-yellow-500 to-yellow-700 shadow-[0_8px_30px_-6px_rgba(250,204,21,0.6)] ring-1 ring-white/15 group-hover:scale-105 transition">
          <HelpCircle className="h-6 w-6 text-white" strokeWidth={2.5} />
          <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 h-2 w-2 rounded-full bg-yellow-300 shadow-[0_0_8px_2px_rgba(250,204,21,0.8)]" />
        </div>
        <div className="leading-none text-left">
          <div className="font-black text-base tracking-[0.18em] text-white">MYSTERY</div>
          <div className="font-black text-base tracking-[0.18em] bg-gradient-to-r from-yellow-400 to-yellow-400 bg-clip-text text-transparent mt-1">MAPS</div>
        </div>
      </button>

      <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-white/80">
        <button onClick={() => onNav("howto")} className="hover:text-white transition">How to Play</button>
        <button onClick={() => onNav("duel")} className="flex items-center gap-1.5 hover:text-fuchsia-300 transition">
          <span className="h-1.5 w-1.5 rounded-full bg-fuchsia-400 animate-pulse" />
          Duel <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-400/40">NEW</span>
        </button>
        <button onClick={() => onNav("achievements")} className="hover:text-white transition">Features</button>
        <button onClick={() => onNav("leaderboard")} className="hover:text-white transition">Leaderboard</button>
        <button onClick={() => onNav("profile")} className="hover:text-white transition">About</button>
      </nav>

      <div className="flex items-center gap-2 sm:gap-3">
        <button
          onClick={onToggleDark}
          aria-label="Toggle theme"
          className="h-10 w-10 flex items-center justify-center rounded-full bg-white/5 border border-white/15 hover:bg-white/10 transition"
        >
          {dark ? <Zap className="h-4 w-4 text-yellow-300" /> : <Sun className="h-4 w-4 text-yellow-500" />}
        </button>
        <AuthButton />
        <button
          onClick={onPlay}
          className="hidden sm:flex items-center gap-2 rounded-full bg-gradient-to-r from-yellow-500 to-yellow-500 text-black px-5 sm:px-6 py-2.5 font-bold text-sm hover:shadow-[0_10px_30px_-8px_rgba(250,204,21,0.7)] transition shadow-lg"
        >
          Start Mission <ArrowRight className="h-4 w-4" />
        </button>
      </div>

    </header>
  );
}

/* ---------- Hero ---------- */

function Hero({ onPlay, onHowTo }: { onPlay: () => void; onHowTo: () => void }) {
  return (
    <section className="relative grid gap-10 lg:grid-cols-2 items-center py-8 sm:py-14 overflow-visible">
      {/* Ambient hero glow */}
      <div className="pointer-events-none absolute -inset-x-10 -top-10 bottom-0 -z-0">
        <div className="absolute left-[10%] top-[10%] h-72 w-72 rounded-full bg-yellow-500/30 blur-[100px] animate-glow-pulse" />
        <div className="absolute right-[8%] top-[30%] h-80 w-80 rounded-full bg-yellow-500/30 blur-[110px] animate-glow-pulse" style={{ animationDelay: "1.4s" }} />
        <div className="absolute left-[40%] bottom-[-10%] h-72 w-72 rounded-full bg-yellow-400/20 blur-[100px] animate-glow-pulse" style={{ animationDelay: "2.6s" }} />
      </div>

      {/* Twinkling stars layer */}
      <TwinkleLayer />

      {/* Left */}
      <div className="relative z-10">
        <span className="inline-flex items-center gap-3 rounded-full bg-white/5 border border-white/15 pl-3 pr-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-white/90 backdrop-blur-sm">
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-yellow-400 animate-pulse" />
            <span className="text-yellow-400">Live Now</span>
          </span>
          <span className="flex -space-x-1.5">
            {["🦊", "🐻", "🐯", "🦁"].map((a, i) => (
              <span key={i} className="h-5 w-5 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 border border-[#000000] flex items-center justify-center text-[10px]">{a}</span>
            ))}
          </span>
          <span className="normal-case tracking-normal text-white/80 text-xs font-semibold">12,438 explorers online</span>
        </span>
        <h1 className="mt-5 font-black text-5xl sm:text-6xl lg:text-7xl leading-[1.05] tracking-tight">
          Guess the Country<br />
          <span className="bg-gradient-to-r from-yellow-400 via-yellow-400 to-yellow-400 bg-clip-text text-transparent drop-shadow-[0_2px_24px_rgba(250,204,21,0.35)]">
            by its Flag.
          </span>
        </h1>
        <p className="mt-6 text-base sm:text-lg text-white/70 max-w-md">
          Race the clock, chase streaks, and travel the world without leaving your seat — one flag at a time.
        </p>

        <div className="mt-7 flex flex-wrap items-center gap-3">
          <button
            onClick={onPlay}
            className="group relative flex items-center gap-2 rounded-full bg-gradient-to-r from-yellow-500 to-yellow-500 text-black px-6 py-3.5 font-bold transition hover:scale-[1.03] shadow-[0_10px_40px_-10px_rgba(250,204,21,0.7)]"
          >
            <span className="absolute inset-0 -z-10 rounded-full bg-yellow-500 blur-xl opacity-50 group-hover:opacity-80 transition" />
            Start Mission <Target className="h-4 w-4 group-hover:rotate-90 transition" />
          </button>
          <button
            onClick={onHowTo}
            className="flex items-center gap-2 rounded-full bg-white/5 border border-white/20 backdrop-blur-sm px-6 py-3.5 font-bold hover:bg-white/15 transition text-white"
          >
            How to Play <Play className="h-4 w-4 fill-current" />
          </button>
        </div>

        {/* Social proof */}
        <div className="mt-7 flex items-center gap-3">
          <div className="flex -space-x-2">
            {["🦊", "🐻", "🐯", "🦁"].map((a, i) => (
              <div key={i} className="h-9 w-9 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-500 border-2 border-[#000000] flex items-center justify-center text-base">
                {a}
              </div>
            ))}
            <div className="h-9 w-9 rounded-full bg-yellow-400 border-2 border-[#000000] flex items-center justify-center text-[10px] font-black text-black">
              50K+
            </div>
          </div>
          <div>
            <div className="text-sm font-bold">Players love this game!</div>
            <div className="flex items-center gap-0.5 text-yellow-400">
              {[0, 1, 2, 3, 4].map((i) => <Star key={i} className="h-3.5 w-3.5 fill-current" />)}
            </div>
          </div>
        </div>
      </div>

      {/* Right - Dynamic flag deck */}
      <div className="relative h-[460px] sm:h-[540px] [perspective:1400px]">
        <FlagDeck />
      </div>
    </section>
  );
}

/* ---------- Dynamic Flag Deck (replaces static globe) ---------- */

const DECK_FLAGS = [
  { code: "BR", name: "Brazil",        continent: "South America" },
  { code: "JP", name: "Japan",         continent: "Asia" },
  { code: "DE", name: "Germany",       continent: "Europe" },
  { code: "FR", name: "France",        continent: "Europe" },
  { code: "IN", name: "India",         continent: "Asia" },
  { code: "ZA", name: "South Africa",  continent: "Africa" },
  { code: "AU", name: "Australia",     continent: "Oceania" },
  { code: "CA", name: "Canada",        continent: "North America" },
  { code: "AR", name: "Argentina",     continent: "South America" },
  { code: "KR", name: "South Korea",   continent: "Asia" },
  { code: "IT", name: "Italy",         continent: "Europe" },
  { code: "EG", name: "Egypt",         continent: "Africa" },
];

function FlagDeck() {
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const reveal = setTimeout(() => setRevealed(true), 1500);
    const next = setTimeout(() => {
      setRevealed(false);
      setIdx((i) => (i + 1) % DECK_FLAGS.length);
    }, 2800);
    return () => { clearTimeout(reveal); clearTimeout(next); };
  }, [idx]);

  const current = DECK_FLAGS[idx];
  const prev = DECK_FLAGS[(idx - 1 + DECK_FLAGS.length) % DECK_FLAGS.length];
  const next = DECK_FLAGS[(idx + 1) % DECK_FLAGS.length];

  return (
    <div className="absolute inset-0">
      {/* Pulse rings — fill the whole frame */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[640px] w-[640px] rounded-full border border-yellow-400/10 animate-spin-slower" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[520px] w-[520px] rounded-full border border-dashed border-yellow-400/20 animate-spin-slow" style={{ animationDirection: "reverse" }} />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[400px] w-[400px] rounded-full border border-yellow-400/15 animate-spin-slower" style={{ animationDuration: "40s" }} />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[360px] w-[360px] rounded-full bg-gradient-to-br from-yellow-400/35 via-yellow-500/15 to-transparent blur-3xl animate-glow-pulse" />

      {/* Back cards (next & prev) — bigger, pushed further out */}
      <div
        key={`back-${next.code}`}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[240px] sm:w-[280px] aspect-[4/3] rounded-2xl overflow-hidden bg-white/5 border-2 border-white/10 shadow-2xl opacity-50 scale-[0.85] -rotate-[12deg] translate-x-[-170px] translate-y-[40px] animate-fade-in"
      >
        <img src={`https://flagcdn.com/w320/${next.code.toLowerCase()}.png`} alt="" className="h-full w-full object-cover" />
      </div>
      <div
        key={`back2-${prev.code}`}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[240px] sm:w-[280px] aspect-[4/3] rounded-2xl overflow-hidden bg-white/5 border-2 border-white/10 shadow-2xl opacity-50 scale-[0.85] rotate-[12deg] translate-x-[170px] translate-y-[40px] animate-fade-in"
      >
        <img src={`https://flagcdn.com/w320/${prev.code.toLowerCase()}.png`} alt="" className="h-full w-full object-cover" />
      </div>

      {/* Main flag card — much bigger to fill the column */}
      <div
        key={`main-${current.code}`}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] sm:w-[420px] aspect-[4/3] rounded-3xl overflow-hidden bg-white border-4 border-black shadow-[0_30px_80px_-15px_rgba(250,204,21,0.7)] animate-pop ring-4 ring-yellow-400/40"
      >
        <img
          src={`https://flagcdn.com/w640/${current.code.toLowerCase()}.png`}
          alt={current.name}
          className="h-full w-full object-cover"
        />
        {!revealed && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/55 backdrop-blur-[2px] animate-fade-in">
            <span className="font-black text-[160px] leading-none text-yellow-400 drop-shadow-[0_0_40px_rgba(250,204,21,0.9)] animate-pulse-glow">?</span>
          </div>
        )}
        {revealed && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/85 text-yellow-300 text-sm font-black px-4 py-2 rounded-full border border-yellow-400/40 backdrop-blur-sm animate-slide-up tracking-wider uppercase">
            {current.code} · {current.name}
          </div>
        )}
      </div>

      {/* Orbiting emoji chips — bigger radius */}
      {["🌍", "🗺️", "✈️", "🧭", "🎯", "🌐"].map((emoji, i) => (
        <div
          key={emoji}
          className="absolute left-1/2 top-1/2 h-0 w-0 animate-orbit"
          style={{
            ["--orbit-r" as string]: "270px",
            animationDuration: "26s",
            animationDelay: `${-i * 4.3}s`,
          }}
        >
          <div className="absolute -translate-x-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-black/80 border border-yellow-400/40 backdrop-blur flex items-center justify-center text-xl shadow-[0_4px_20px_rgba(250,204,21,0.4)]">
            {emoji}
          </div>
        </div>
      ))}
      {/* Inner reverse-orbit mini flags */}
      {["BR", "JP", "FR", "IN"].map((code, i) => (
        <div
          key={code}
          className="absolute left-1/2 top-1/2 h-0 w-0 animate-orbit-rev"
          style={{
            ["--orbit-r" as string]: "200px",
            animationDuration: "18s",
            animationDelay: `${-i * 4.5}s`,
          }}
        >
          <div className="absolute -translate-x-1/2 -translate-y-1/2 h-10 w-14 rounded-md overflow-hidden border-2 border-black shadow-lg">
            <img src={`https://flagcdn.com/w80/${code.toLowerCase()}.png`} alt="" className="h-full w-full object-cover" />
          </div>
        </div>
      ))}

      {/* Counter pill */}
      <div className="absolute top-2 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 bg-black/80 border border-yellow-400/40 backdrop-blur-md rounded-full px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-yellow-300 shadow-[0_8px_30px_-6px_rgba(250,204,21,0.5)]">
        <span className="h-1.5 w-1.5 rounded-full bg-yellow-400 animate-pulse" />
        Flag {idx + 1} / {DECK_FLAGS.length}
        <span className="text-white/50">·</span>
        <span className="text-white/80 normal-case tracking-normal">{current.continent}</span>
      </div>


      {/* Corner badges fill the dead space */}
      <div className="absolute top-[14%] left-[2%] rotate-[-8deg] bg-yellow-400 text-black text-[10px] font-black px-2.5 py-1 rounded-md border-2 border-black shadow-lg animate-float">
        +50 XP
      </div>
      <div className="absolute top-[10%] right-[2%] rotate-[8deg] bg-black text-yellow-300 text-[10px] font-black px-2.5 py-1 rounded-md border-2 border-yellow-400/50 backdrop-blur animate-float" style={{ animationDelay: "1.2s" }}>
        🔥 STREAK
      </div>
      <div className="absolute bottom-[18%] left-[3%] rotate-[6deg] bg-black text-yellow-300 text-[10px] font-black px-2.5 py-1 rounded-md border-2 border-yellow-400/50 backdrop-blur animate-float" style={{ animationDelay: "2s" }}>
        195 COUNTRIES
      </div>
      <div className="absolute bottom-[22%] right-[3%] rotate-[-6deg] bg-yellow-400 text-black text-[10px] font-black px-2.5 py-1 rounded-md border-2 border-black shadow-lg animate-float" style={{ animationDelay: "0.6s" }}>
        ⚡ 10s
      </div>

      {/* Sparkles spread across */}
      <span className="absolute top-[8%] right-[26%] text-yellow-300 text-xl animate-twinkle">✦</span>
      <span className="absolute top-[22%] left-[18%] text-yellow-300 text-base animate-twinkle" style={{ animationDelay: "1s" }}>✦</span>
      <span className="absolute bottom-[30%] left-[22%] text-yellow-300 text-lg animate-twinkle" style={{ animationDelay: "2s" }}>✦</span>
      <span className="absolute bottom-[36%] right-[18%] text-yellow-300 text-base animate-twinkle" style={{ animationDelay: "0.6s" }}>✦</span>
      <span className="absolute top-[40%] right-[6%] text-yellow-300 text-sm animate-twinkle" style={{ animationDelay: "1.5s" }}>✦</span>
      <span className="absolute top-[50%] left-[4%] text-yellow-300 text-sm animate-twinkle" style={{ animationDelay: "2.4s" }}>✦</span>
    </div>
  );
}

/* ---------- Globe scene with orbiting landmarks ---------- */


const ORBIT_ITEMS = [
  { emoji: "🗼", label: "Paris",    r: 170, d: 0,    dur: "26s" },
  { emoji: "🗽", label: "New York", r: 170, d: 90,   dur: "26s" },
  { emoji: "🏯", label: "Kyoto",    r: 170, d: 180,  dur: "26s" },
  { emoji: "🕌", label: "Istanbul", r: 170, d: 270,  dur: "26s" },
];
const ORBIT_ITEMS_OUTER = [
  { emoji: "🛕", label: "Delhi",    r: 230, d: 45,   dur: "34s" },
  { emoji: "🏛️", label: "Athens",   r: 230, d: 225,  dur: "34s" },
];

function GlobeScene() {
  return (
    <div className="absolute inset-0">
      {/* Soft halo rings */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[360px] w-[360px] rounded-full border border-white/10" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[460px] w-[460px] rounded-full border border-dashed border-white/10" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[300px] w-[300px] rounded-full bg-gradient-to-br from-yellow-400/20 via-yellow-500/10 to-transparent blur-2xl" />

      {/* Globe */}
      <img
        src={globeImg}
        alt="Earth globe"
        width={1024}
        height={1024}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[260px] sm:w-[320px] drop-shadow-[0_20px_60px_rgba(250,204,21,0.4)] animate-float"
      />

      {/* Compass overlay (spins slowly behind globe) */}
      <Compass className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[380px] w-[380px] text-yellow-300/10 animate-spin-slower" strokeWidth={0.5} />

      {/* Dashed flight paths */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 500 540" fill="none" preserveAspectRatio="none">
        <defs>
          <linearGradient id="pathGrad" x1="0" x2="1">
            <stop offset="0%" stopColor="#7dd3fc" stopOpacity="0" />
            <stop offset="50%" stopColor="#7dd3fc" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#a78bfa" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d="M 40 110 Q 250 30 460 130" stroke="url(#pathGrad)" strokeWidth="1.5" strokeDasharray="5 7" className="animate-dash" />
        <path d="M 60 410 Q 250 480 440 400" stroke="url(#pathGrad)" strokeWidth="1.5" strokeDasharray="5 7" className="animate-dash" style={{ animationDirection: "reverse" }} />
        <path d="M 30 270 Q 250 180 470 280" stroke="url(#pathGrad)" strokeWidth="1" strokeDasharray="3 9" className="animate-dash" />
      </svg>

      {/* Flying planes along curved paths */}
      <FlyingPlane d="M 40 110 Q 250 30 460 130" />
      <FlyingPlane d="M 60 410 Q 250 480 440 400" delay="6s" />

      {/* Orbit center */}
      <div className="absolute left-1/2 top-1/2 h-0 w-0">
        {ORBIT_ITEMS.map((it, i) => (
          <OrbitChip key={i} {...it} />
        ))}
        {ORBIT_ITEMS_OUTER.map((it, i) => (
          <OrbitChip key={`o-${i}`} {...it} variant="outer" />
        ))}
      </div>

      {/* Floating passport stamps */}
      <Stamp className="absolute top-[2%] left-[2%]" rotate={-14} color="rose"  label="VISA · TYO" sub="2024" />
      <Stamp className="absolute top-[6%] right-[4%]" rotate={9}   color="cyan"  label="ARRIVAL · CDG" sub="PARIS" />
      <Stamp className="absolute bottom-[2%] left-[6%]" rotate={6} color="emerald" label="STAMPED · RIO" sub="BR" />
      <Stamp className="absolute bottom-[6%] right-[2%]" rotate={-7} color="amber"  label="DEPART · JFK" sub="USA" />

      {/* Floating mini flag cards */}
      {FLOATING_FLAGS.map((f, i) => (
        <FlagCard key={f.code} code={f.code} className={f.className} delay={i * 0.6} />
      ))}

      {/* Map pins drifting */}
      <MapPin className="absolute top-[18%] left-[14%] h-5 w-5 text-yellow-400 animate-drift-x" />
      <MapPin className="absolute bottom-[22%] right-[12%] h-5 w-5 text-yellow-300 animate-drift-x" style={{ animationDelay: "2s" }} />
      <Landmark className="absolute top-[32%] right-[8%] h-5 w-5 text-yellow-300/80 animate-drift-x" style={{ animationDelay: "4s" }} />

      {/* Sparkles */}
      <span className="absolute top-[12%] right-[22%] text-yellow-300 text-xl animate-twinkle">✦</span>
      <span className="absolute top-[30%] right-[10%] text-yellow-300 text-base animate-twinkle" style={{ animationDelay: "1s" }}>✦</span>
      <span className="absolute bottom-[24%] left-[18%] text-yellow-300 text-lg animate-twinkle" style={{ animationDelay: "2s" }}>✦</span>
      <span className="absolute top-[18%] left-[34%] text-2xl text-yellow-300/70 animate-twinkle" style={{ animationDelay: "0.5s" }}>?</span>

      {/* Bottom info card */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[230px] sm:w-[260px] bg-white/95 text-black rounded-2xl shadow-[0_20px_50px_-10px_rgba(250,204,21,0.5)] backdrop-blur p-4 pt-8 rotate-[-2deg] ring-1 ring-white/40">
        <img
          src={brainImg}
          alt=""
          width={512}
          height={512}
          className="absolute -top-10 left-1/2 -translate-x-1/2 w-20 drop-shadow-lg animate-float"
          loading="lazy"
        />
        <p className="text-center font-black text-base mt-2">Learn. Play. Explore.</p>
        <p className="text-center text-xs text-black/60 mt-1 leading-snug">
          195 countries · 50k+ players · endless adventure
        </p>
      </div>
    </div>
  );
}

function OrbitChip({ emoji, label, r, d, dur, variant }: { emoji: string; label: string; r: number; d: number; dur: string; variant?: "outer" }) {
  return (
    <div
      className={variant === "outer" ? "absolute animate-orbit-rev" : "absolute animate-orbit"}
      style={{
        ["--orbit-r" as string]: `${r}px`,
        animationDuration: dur,
        animationDelay: `${-d / 360 * parseFloat(dur)}s`,
      }}
    >
      <div className="-translate-x-1/2 -translate-y-1/2 flex items-center gap-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 px-2.5 py-1.5 shadow-lg shadow-black/30">
        <span className="text-base leading-none">{emoji}</span>
        <span className="text-[10px] font-bold uppercase tracking-wider text-white/90">{label}</span>
      </div>
    </div>
  );
}

function FlyingPlane({ d, delay = "0s" }: { d: string; delay?: string }) {
  return (
    <div className="pointer-events-none absolute inset-0">
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 500 540" preserveAspectRatio="none">
        <path id={`p-${d.length}-${delay}`} d={d} fill="none" />
      </svg>
      <div
        className="absolute top-0 left-0 animate-plane"
        style={{
          offsetPath: `path("${d}")`,
          offsetRotate: "auto",
          animationDelay: delay,
        } as React.CSSProperties}
      >
        <Plane className="h-4 w-4 text-yellow-300 drop-shadow-[0_0_8px_rgba(250,204,21,0.8)]" fill="currentColor" />
      </div>
    </div>
  );
}

function FlagCard({ code, className, delay }: { code: string; className: string; delay: number }) {
  return (
    <div className={`absolute ${className} animate-float`} style={{ animationDelay: `${delay}s` }}>
      <div className="relative rounded-xl bg-white/10 backdrop-blur-md border border-white/25 p-1.5 shadow-2xl shadow-black/40 hover:scale-110 transition">
        <img
          src={`https://flagcdn.com/w160/${code.toLowerCase()}.png`}
          alt={code}
          className="rounded-md w-full h-auto block"
          loading="lazy"
        />
        <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 rounded-full bg-black text-yellow-300 text-[9px] font-black px-2 py-0.5 border border-white/20">
          {code}
        </span>
      </div>
    </div>
  );
}

function Stamp({ className, rotate, color, label, sub }: { className: string; rotate: number; color: "rose" | "cyan" | "emerald" | "amber"; label: string; sub: string }) {
  const map = {
    rose:    "border-yellow-300/70 text-yellow-200",
    cyan:    "border-yellow-300/70 text-yellow-200",
    emerald: "border-yellow-300/70 text-yellow-200",
    amber:   "border-yellow-300/70 text-yellow-200",
  } as const;
  return (
    <div
      className={`${className} animate-stamp`}
      style={{ ["--stamp-r" as string]: `${rotate}deg`, animationDelay: `${Math.random() * 0.8}s` }}
    >
      <div className={`rounded-md border-2 border-dashed ${map[color]} px-2.5 py-1 bg-white/5 backdrop-blur-sm shadow-lg`}>
        <div className="font-mono text-[9px] font-black tracking-[0.18em] leading-tight">{label}</div>
        <div className="font-mono text-[8px] tracking-[0.2em] opacity-70 leading-tight">{sub}</div>
      </div>
    </div>
  );
}

function TwinkleLayer() {
  const stars = Array.from({ length: 24 });
  return (
    <div className="pointer-events-none absolute inset-0 -z-0">
      {stars.map((_, i) => {
        const top = (i * 37) % 100;
        const left = (i * 53) % 100;
        const size = (i % 3) + 1;
        return (
          <span
            key={i}
            className="absolute rounded-full bg-white animate-twinkle"
            style={{
              top: `${top}%`,
              left: `${left}%`,
              width: `${size}px`,
              height: `${size}px`,
              animationDelay: `${(i % 7) * 0.4}s`,
              opacity: 0.6,
            }}
          />
        );
      })}
    </div>
  );
}



/* ---------- Stats Row ---------- */

function StatsRow() {
  return (
    <section className="relative mb-5">
      <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-white/[0.02] backdrop-blur-md p-5 sm:p-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {STATS.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="flex items-center gap-4">
                <div className={`h-14 w-14 rounded-2xl flex items-center justify-center bg-white/5 ring-1 ring-white/10 ${s.color}`}>
                  <Icon className="h-7 w-7" strokeWidth={2.2} />
                </div>
                <div className="leading-tight">
                  <div className={`text-2xl sm:text-3xl font-black ${s.color}`}>{s.value}</div>
                  <div className="text-sm font-bold text-white">{s.label}</div>
                  <div className="text-[11px] text-white/50">{s.sub}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------- Features ---------- */

function FeatureRow() {
  return (
    <section className="relative mb-10">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {FEATURES.map((f) => {
          const Icon = f.icon;
          return (
            <div key={f.title} className={`group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-white/[0.01] backdrop-blur-md p-5 hover:-translate-y-1 transition ring-1 ${f.ring}`}>
              <div className={`absolute -top-10 -right-10 h-32 w-32 rounded-full blur-2xl ${f.glow}`} />
              <div className={`relative h-12 w-12 rounded-xl flex items-center justify-center bg-white/5 ring-1 ring-white/10 mb-4 ${f.color}`}>
                <Icon className="h-6 w-6" strokeWidth={2.2} />
              </div>
              <h3 className="relative font-bold text-base text-white mb-1.5">{f.title}</h3>
              <p className="relative text-sm text-white/60 leading-snug mb-6">{f.desc}</p>
              <button className="relative h-8 w-8 rounded-full bg-white/5 ring-1 ring-white/15 flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition">
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          );
        })}
      </div>
    </section>
  );
}

/* ---------- Country strip ---------- */

function CountryStrip() {
  return (
    <section className="rounded-3xl bg-white/5 border border-white/10 backdrop-blur-sm px-4 sm:px-8 py-6 mb-10">
      <div className="flex items-center justify-center gap-2 text-sm font-semibold mb-4">
        <Heart className="h-4 w-4 text-yellow-400 fill-yellow-400" />
        <span>Loved by players around the world</span>
        <Heart className="h-4 w-4 text-yellow-400 fill-yellow-400" />
      </div>
      <div className="flex flex-wrap items-end justify-center gap-x-6 gap-y-4 sm:gap-x-10">
        {POPULAR_COUNTRIES.map((c) => (
          <div key={c.code} className="flex flex-col items-center gap-1.5">
            <img
              src={`https://flagcdn.com/w80/${c.code.toLowerCase()}.png`}
              alt={c.name}
              className="h-10 w-auto rounded shadow-md ring-1 ring-black/20"
              loading="lazy"
            />
            <span className="text-xs font-semibold opacity-80">{c.name}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- Footer ---------- */

function Footer() {
  return (
    <footer className="py-8 text-center text-xs text-white/50">
      © {new Date().getFullYear()} MysteryMaps · Built with ❤ for flag lovers
    </footer>
  );
}

/* ---------- Backdrop ---------- */

function BgPattern({ dark }: { dark: boolean }) {
  if (!dark) return null;
  const dotMap = DOT_MAP_URL;
  return (
    <>
      {/* dot grid */}
      <div
        className="pointer-events-none fixed inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "radial-gradient(circle, rgba(250,204,21,0.9) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />
      {/* slow-rotating conic gradient — the "spotlight" */}
      <div
        className="pointer-events-none fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[140vmax] w-[140vmax] opacity-[0.10] animate-spin-slower"
        style={{
          background:
            "conic-gradient(from 0deg, rgba(250,204,21,0) 0deg, rgba(250,204,21,0.55) 40deg, rgba(250,204,21,0) 80deg, rgba(250,204,21,0) 200deg, rgba(250,204,21,0.45) 240deg, rgba(250,204,21,0) 280deg)",
        }}
      />
      {/* slow-panning world dot map */}
      <div
        className="pointer-events-none fixed inset-0 opacity-[0.18] animate-map-pan"
        style={{
          backgroundImage: `url("${dotMap}")`,
          backgroundRepeat: "repeat-x",
          backgroundSize: "1200px auto",
          backgroundPosition: "center",
          maskImage: "radial-gradient(ellipse at center, black 40%, transparent 80%)",
          WebkitMaskImage: "radial-gradient(ellipse at center, black 40%, transparent 80%)",
        }}
      />
      {/* drifting grid lines */}
      <div
        className="pointer-events-none fixed inset-0 opacity-[0.07] grid-bg"
      />
      {/* aurora blobs */}
      <div className="pointer-events-none fixed -top-40 -left-40 h-[500px] w-[500px] rounded-full bg-yellow-600/30 blur-3xl animate-glow-pulse" />
      <div className="pointer-events-none fixed -bottom-40 -right-40 h-[500px] w-[500px] rounded-full bg-yellow-600/30 blur-3xl animate-glow-pulse" style={{ animationDelay: "2s" }} />
      <div className="pointer-events-none fixed top-1/3 left-1/2 -translate-x-1/2 h-[400px] w-[700px] rounded-full bg-yellow-500/15 blur-[120px] animate-glow-pulse" style={{ animationDelay: "3.5s" }} />

      {/* drifting particles */}
      {Array.from({ length: 14 }).map((_, i) => {
        const top = (i * 73) % 100;
        const left = (i * 137) % 100;
        const size = 2 + (i % 4);
        const delay = (i * 0.7) % 6;
        const dur = 4 + (i % 5);
        return (
          <span
            key={i}
            className="pointer-events-none fixed rounded-full bg-yellow-300/70 animate-twinkle"
            style={{
              top: `${top}%`,
              left: `${left}%`,
              width: `${size}px`,
              height: `${size}px`,
              animationDelay: `${delay}s`,
              animationDuration: `${dur}s`,
              boxShadow: "0 0 8px rgba(250,204,21,0.7)",
            }}
          />
        );
      })}
    </>
  );
}



/* ---------- Sub views ---------- */

function PanelView({ title, children, onBack }: { title: string; children: React.ReactNode; onBack: () => void }) {
  return (
    <div className="py-8 max-w-3xl mx-auto animate-slide-up">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-3xl font-black tracking-tight">{title}</h2>
        <button onClick={onBack} className="flex items-center gap-1.5 rounded-full bg-white/10 border border-white/20 hover:bg-white/20 px-4 py-2 font-semibold text-sm transition">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
      </div>
      <div className="rounded-3xl border border-white/10 bg-white/5 backdrop-blur-sm p-5 sm:p-6">
        {children}
      </div>
    </div>
  );
}

function OptionsView({
  rounds, difficulty, onRounds, onDifficulty, onBack, onPlay,
}: {
  rounds: number; difficulty: Difficulty;
  onRounds: (n: number) => void; onDifficulty: (d: Difficulty) => void;
  onBack: () => void; onPlay: () => void;
}) {
  return (
    <PanelView title="Game Options" onBack={onBack}>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest mb-3 opacity-80">Questions per round</p>
          <div className="grid grid-cols-4 gap-2">
            {ROUND_OPTIONS.map((n) => (
              <button
                key={n}
                onClick={() => onRounds(n)}
                className={`rounded-xl px-2 py-3 text-base font-bold transition ${rounds === n ? "bg-yellow-400 text-black" : "bg-white/10 hover:bg-white/20"}`}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-widest mb-3 opacity-80">Difficulty</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {DIFFICULTY_OPTIONS.map((d) => (
              <button
                key={d.id}
                onClick={() => onDifficulty(d.id)}
                className={`rounded-xl px-3 py-3 text-left transition ${difficulty === d.id ? "bg-yellow-400 text-black" : "bg-white/10 hover:bg-white/20"}`}
              >
                <div className="text-sm font-bold">{d.label}</div>
                <div className="text-[11px] opacity-80 leading-tight">{d.desc}</div>
              </button>
            ))}
          </div>
        </div>
        <button
          onClick={onPlay}
          className="w-full flex items-center justify-center gap-2 rounded-xl bg-yellow-500 hover:bg-yellow-600 text-black py-3.5 font-bold text-base transition shadow-lg shadow-yellow-500/30"
        >
          <Play className="h-4 w-4 fill-current" /> Play · {rounds}Q · {difficulty}
        </button>
      </div>
    </PanelView>
  );
}

/* ---------- Setup (after Play Now) ---------- */

function SetupView({
  rounds, difficulty, category, mode,
  onRounds, onDifficulty, onCategory, onMode, onBack, onPlay,
}: {
  rounds: number; difficulty: Difficulty; category: CategorySelection; mode: GameMode;
  onRounds: (n: number) => void;
  onDifficulty: (d: Difficulty) => void;
  onCategory: (c: CategorySelection) => void;
  onMode: (m: GameMode) => void;
  onBack: () => void; onPlay: () => void;
}) {
  const isRapid = mode === "rapid";
  const typeLabel = category.kind === "continent" ? category.continent : category.kind === "oceans" ? "Oceans" : "General";
  const summary = isRapid
    ? `Rapid Fire · 10s · 7Q · ${difficulty}`
    : `${rounds}Q · ${difficulty} · ${typeLabel}`;

  const tile = (active: boolean, accent: "amber" | "emerald" | "sky" | "fuchsia" = "amber") => {
    const accents: Record<string, string> = {
      amber:    "from-yellow-300/90 to-yellow-400/90 ring-yellow-300/60 shadow-[0_10px_40px_-12px_rgba(250,204,21,0.7)]",
      emerald:  "from-yellow-300/90 to-yellow-400/90 ring-yellow-300/60 shadow-[0_10px_40px_-12px_rgba(250,204,21,0.7)]",
      sky:      "from-yellow-300/90 to-yellow-400/90 ring-yellow-300/60 shadow-[0_10px_40px_-12px_rgba(250,204,21,0.7)]",
      fuchsia:  "from-yellow-300/90 to-yellow-400/90 ring-yellow-300/60 shadow-[0_10px_40px_-12px_rgba(250,204,21,0.7)]",
    };
    return active
      ? `bg-gradient-to-br ${accents[accent]} text-black ring-2 scale-[1.02]`
      : "bg-white/[0.04] hover:bg-white/[0.09] text-white ring-1 ring-white/10 hover:ring-white/25 hover:-translate-y-0.5";
  };

  const SectionLabel = ({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) => (
    <div className="flex items-center gap-2 mb-3">
      <span className="grid place-items-center h-7 w-7 rounded-lg bg-gradient-to-br from-white/15 to-white/5 ring-1 ring-white/10 text-yellow-300">
        {icon}
      </span>
      <p className="text-[11px] font-black uppercase tracking-[0.2em] text-white/70">{children}</p>
      <span className="flex-1 h-px bg-gradient-to-r from-white/15 to-transparent" />
    </div>
  );

  return (
    <div className="py-8 max-w-3xl mx-auto animate-slide-up relative">
      {/* Ambient glow */}
      <div className="pointer-events-none absolute -top-10 left-1/2 -translate-x-1/2 h-64 w-[80%] rounded-full bg-yellow-400/10 blur-3xl" />
      <div className="pointer-events-none absolute bottom-10 right-0 h-56 w-56 rounded-full bg-yellow-500/10 blur-3xl" />

      <div className="flex items-center justify-between mb-5 relative">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-[0.3em] text-yellow-300/90 mb-1">Mission Briefing</p>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight bg-gradient-to-r from-white via-yellow-100 to-yellow-300 bg-clip-text text-transparent">
            Configure Your Run
          </h2>
        </div>
        <button onClick={onBack} className="flex items-center gap-1.5 rounded-full bg-white/10 border border-white/20 hover:bg-white/20 px-4 py-2 font-semibold text-sm transition">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
      </div>

      <div className="relative rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.07] to-white/[0.02] backdrop-blur-xl p-5 sm:p-7 shadow-[0_30px_80px_-30px_rgba(250,204,21,0.7)] overflow-hidden">
        {/* Decorative top border shimmer */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-yellow-300/60 to-transparent" />

        <div className="space-y-7 relative">
          {/* MODE */}
          <div>
            <SectionLabel icon={<Zap className="h-3.5 w-3.5" />}>Mode</SectionLabel>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                onClick={() => onMode("classic")}
                className={`group rounded-2xl p-4 text-left transition-all duration-200 ${tile(mode === "classic", "amber")}`}
              >
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  <div className="text-base font-black">Classic</div>
                </div>
                <div className="text-[11px] mt-1 opacity-80 leading-tight">Per-question timer · 3 lives</div>
              </button>
              <button
                onClick={() => onMode("rapid")}
                className={`group rounded-2xl p-4 text-left transition-all duration-200 ${tile(mode === "rapid", "fuchsia")}`}
              >
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  <div className="text-base font-black">Rapid Fire</div>
                </div>
                <div className="text-[11px] mt-1 opacity-80 leading-tight">10s · 7 countries · skip allowed</div>
              </button>
              <button
                onClick={() => onMode("lookalike")}
                className={`group rounded-2xl p-4 text-left transition-all duration-200 ${tile(mode === "lookalike", "sky")}`}
              >
                <div className="flex items-center gap-2">
                  <HelpCircle className="h-5 w-5" />
                  <div className="text-base font-black">Lookalike</div>
                </div>
                <div className="text-[11px] mt-1 opacity-80 leading-tight">Twin flags · 2–4 options (NZ vs AU…)</div>
              </button>
            </div>

          </div>

          {/* QUESTIONS */}
          <div className={isRapid ? "opacity-40 pointer-events-none" : ""}>
            <SectionLabel icon={<Star className="h-3.5 w-3.5" />}>
              Questions {isRapid && <span className="ml-1 normal-case tracking-normal opacity-70">(fixed at 7)</span>}
            </SectionLabel>
            <div className="grid grid-cols-4 gap-3">
              {ROUND_OPTIONS.map((n) => (
                <button
                  key={n}
                  onClick={() => onRounds(n)}
                  className={`rounded-2xl py-4 text-xl font-black transition-all duration-200 ${tile(rounds === n, "sky")}`}
                >
                  {n}
                  <div className="text-[10px] font-bold opacity-70 mt-0.5">QUESTIONS</div>
                </button>
              ))}
            </div>
          </div>

          {/* DIFFICULTY */}
          <div>
            <SectionLabel icon={<Trophy className="h-3.5 w-3.5" />}>Difficulty</SectionLabel>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {DIFFICULTY_OPTIONS.map((d) => (
                <button
                  key={d.id}
                  onClick={() => onDifficulty(d.id)}
                  className={`rounded-2xl p-4 text-left transition-all duration-200 ${tile(difficulty === d.id, "emerald")}`}
                >
                  <div className="text-2xl">{d.emoji}</div>
                  <div className="text-sm font-black mt-1">{d.label}</div>
                  <div className="text-[11px] opacity-80 leading-tight">{d.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* TYPE */}
          <div>
            <SectionLabel icon={<Globe2 className="h-3.5 w-3.5" />}>Type</SectionLabel>
            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => onCategory({ kind: "continent", continent: (category.kind === "continent" ? category.continent : "Asia") })}
                className={`rounded-2xl p-4 text-left transition-all duration-200 ${tile(category.kind === "continent", "amber")}`}
              >
                <div className="text-xl">🌎</div>
                <div className="text-sm font-black mt-1">Continent</div>
                <div className="text-[11px] opacity-80 leading-tight">Pick a continent</div>
              </button>
              <button
                onClick={() => onCategory({ kind: "oceans" })}
                className={`rounded-2xl p-4 text-left transition-all duration-200 ${tile(category.kind === "oceans", "sky")}`}
              >
                <div className="text-xl">🌊</div>
                <div className="text-sm font-black mt-1">Oceans</div>
                <div className="text-[11px] opacity-80 leading-tight">Oceania islands</div>
              </button>
              <button
                onClick={() => onCategory({ kind: "general" })}
                className={`rounded-2xl p-4 text-left transition-all duration-200 ${tile(category.kind === "general", "fuchsia")}`}
              >
                <div className="text-xl">🌐</div>
                <div className="text-sm font-black mt-1">General</div>
                <div className="text-[11px] opacity-80 leading-tight">All countries</div>
              </button>
            </div>

            {category.kind === "continent" && (
              <div className="mt-3 grid grid-cols-3 sm:grid-cols-6 gap-2 animate-fade-in">
                {CONTINENTS.map((c) => (
                  <button
                    key={c}
                    onClick={() => onCategory({ kind: "continent", continent: c })}
                    className={`rounded-xl px-2 py-2.5 text-xs font-bold transition-all ${
                      category.continent === c
                        ? "bg-gradient-to-br from-yellow-300 to-yellow-400 text-black ring-2 ring-yellow-300/60 scale-[1.03]"
                        : "bg-white/[0.04] hover:bg-white/[0.1] ring-1 ring-white/10 hover:ring-white/25"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Summary bar */}
          <div className="rounded-2xl p-4 bg-gradient-to-r from-white/[0.05] to-white/[0.02] border border-white/10 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs font-bold uppercase tracking-wider">
            <span className="flex items-center gap-1.5"><Zap className="h-3.5 w-3.5 text-yellow-300" /> {isRapid ? "Rapid" : "Classic"}</span>
            <span className="flex items-center gap-1.5"><Star className="h-3.5 w-3.5 text-yellow-300" /> {isRapid ? 7 : rounds} Qs</span>
            <span className="flex items-center gap-1.5"><Trophy className="h-3.5 w-3.5 text-yellow-300" /> {difficulty}</span>
            <span className="flex items-center gap-1.5"><Globe2 className="h-3.5 w-3.5 text-yellow-300" /> {typeLabel}</span>
          </div>

          {/* CTA */}
          <button
            onClick={onPlay}
            className="group relative w-full overflow-hidden rounded-2xl py-5 font-black text-base text-black transition-transform active:scale-[0.99]"
          >
            <span className="absolute inset-0 bg-gradient-to-r from-yellow-300 via-yellow-400 to-yellow-300 bg-[length:200%_100%] animate-[map-pan_3s_linear_infinite] group-hover:from-yellow-200 group-hover:to-yellow-300" />
            <span className="absolute inset-0 shadow-[0_18px_60px_-15px_rgba(250,204,21,0.8)]" />
            <span className="relative flex items-center justify-center gap-2 tracking-wide">
              <Rocket className="h-5 w-5" /> Launch · {summary}
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}

function ProfileView({ profile, setProfile, onBack }: { profile: Profile; setProfile: (p: Profile) => void; onBack: () => void }) {
  const [name, setName] = useState(profile.username);
  const lvl = levelFromXp(profile.xp);
  const acc = profile.totalPlayed ? Math.round((profile.totalCorrect / profile.totalPlayed) * 100) : 0;
  const saveName = () => setProfile({ ...profile, username: name.trim() || "Explorer" });

  return (
    <PanelView title="Profile" onBack={onBack}>
      <div className="flex items-center gap-4">
        <div className="text-5xl rounded-2xl bg-white/10 border border-white/20 p-3">{profile.avatar}</div>
        <div className="flex-1">
          <div className="flex gap-2">
            <Input value={name} onChange={(e) => setName(e.target.value)} className="h-10 bg-white/10 border-white/20 text-white" />
            <Button onClick={saveName} className="bg-yellow-400 text-black hover:bg-yellow-300 font-bold">Save</Button>
          </div>
          <p className="mt-2 text-xs font-semibold uppercase tracking-widest opacity-80">Lv. {lvl.level} · {profile.xp} XP · {acc}% Acc</p>
        </div>
      </div>
    </PanelView>
  );
}
