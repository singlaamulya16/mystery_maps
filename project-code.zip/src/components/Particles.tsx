import { useEffect, useRef } from "react";

export function ParticleBurst({ trigger, color = "primary" }: { trigger: number; color?: "primary" | "success" | "destructive" | "accent" }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!trigger || !ref.current) return;
    const el = ref.current;
    const particles: HTMLSpanElement[] = [];
    const colorVar = `var(--${color})`;
    for (let i = 0; i < 24; i++) {
      const p = document.createElement("span");
      const angle = (Math.PI * 2 * i) / 24 + Math.random() * 0.3;
      const dist = 80 + Math.random() * 120;
      const dx = Math.cos(angle) * dist;
      const dy = Math.sin(angle) * dist;
      const size = 10 + Math.random() * 8;
      p.style.cssText = `
        position:absolute;left:50%;top:50%;width:${size}px;height:${size}px;
        background:${colorVar};border:2px solid #111;pointer-events:none;
        transform:translate(-50%,-50%) rotate(${Math.random()*360}deg);will-change:transform,opacity;
      `;
      el.appendChild(p);
      particles.push(p);
      requestAnimationFrame(() => {
        p.animate(
          [
            { transform: "translate(-50%,-50%) scale(1)", opacity: 1 },
            { transform: `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px)) scale(0)`, opacity: 0 },
          ],
          { duration: 700 + Math.random() * 300, easing: "cubic-bezier(0.16,1,0.3,1)" }
        ).onfinish = () => p.remove();
      });
    }
    return () => particles.forEach((p) => p.remove());
  }, [trigger, color]);

  return <div ref={ref} className="pointer-events-none absolute inset-0 z-30" aria-hidden />;
}

export function FloatingOrbs() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
      <div className="absolute top-16 -left-10 h-40 w-40 bg-primary border-[3px] border-foreground animate-float" style={{ boxShadow: "8px 8px 0 0 #111" }} />
      <div className="absolute top-1/3 -right-12 h-52 w-52 rounded-full bg-accent border-[3px] border-foreground animate-float" style={{ animationDelay: "2s", boxShadow: "8px 8px 0 0 #111" }} />
      <div className="absolute bottom-10 left-1/4 h-32 w-32 bg-secondary border-[3px] border-foreground rotate-12 animate-float" style={{ animationDelay: "4s", boxShadow: "8px 8px 0 0 #111" }} />
      <div className="absolute bottom-32 right-1/4 h-24 w-24 bg-success border-[3px] border-foreground -rotate-6 animate-float" style={{ animationDelay: "1s", boxShadow: "6px 6px 0 0 #111" }} />
    </div>
  );
}
